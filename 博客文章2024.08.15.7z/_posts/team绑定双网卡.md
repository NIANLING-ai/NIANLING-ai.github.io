---
title: team绑定双网卡
date: 2024-01-13 09:25:00
updated: 2024-01-13 09:25:00
tags: [双网卡绑定,team]
excerpt: 服务器绑定双网卡，做负载
categories: [Linux, team]
---
# team绑定双网卡

注意：虚拟机里做，一定要额外添加两块网卡才行，总共三块网卡

```bash
# 查看所有的网络连接
nmcli con show

# 创建 team 接口及其配置，并将 ens38、ens37 加入 ifcfg-team0
nmcli con add type team con-name team0 ifname ifcfg-team0 config '{"runner":{"name":"activebackup"}}'
nmcli con mod team0 ipv4.addresses "192.168.147.100/24" ipv4.gateway "192.168.147.2" ipv4.dns "192.168.147.2" ipv4.method manual

nmcli con add type team-slave con-name team0-port1 ifname ens224 master ifcfg-team0
nmcli con add type team-slave con-name team0-port2 ifname ens256 master ifcfg-team0

# 激活 team0 及其端口
nmcli con up team0
nmcli con up team0-port1
nmcli con up team0-port2
# 查看 ifcfg-team0 网卡绑定的信息
teamdctl ifcfg-team0 state

# 测试网络连通性并停用端口，物理机直接轮流拔掉网口测试
ping -c 4 192.168.147.2 &  # 在后台持续 ping DNS
nmcli con down team0-port1  # 停用端口1
```