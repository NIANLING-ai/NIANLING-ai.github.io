---
title: FTP安装并配置虚拟用户
date: 2024-01-19 09:25:00
updated: 2024-01-19 09:25:00
tags: [Linux, FTP]
excerpt: Linux配置FTP的一部分，主要针对虚拟用户，其余部分见详细文章
categories: [运维, Linux ]
---
## FTP安装并配置虚拟用户

### 1.安装软件

```bash
yum -y install vsftpd
```

### 2.创建相应的ftp数据目录

```bash
mkdir -p /data/ftp/zhang
```

### 3.创建一个用户提供给虚拟用户使用

```bash
useradd -s /sbin/nologin virtual
```

### 4.将ftp数据目录设置成virtual用户

```bash
chown virtual. /data/ftp/zhang -R
ll /data/ftp/
```

* **创建虚拟帐号与密码的文本文件(一行账号，一行密码, 注意不要有多余的空格)**

```bash
vim /etc/vsftpd/logins.txt
testzhang
zhang@123
```

### 5.**将创建好的密码文件txt格式转换db格式**

```bash
db_load -T -t hash -f /etc/vsftpd/logins.txt /etc/vsftpd/login.db
```

### 6.**定义db文件的权限**

```bash
chmod 600 /etc/vsftpd/login.db
```

* **定义pam认证文件（注意：db=/etc/vsftpd/login 文件就是上面生成的login.db文件；省略后缀.db）**

```bash
vim /etc/pam.d/ftp
auth  required  /lib64/security/pam_userdb.so  db=/etc/vsftpd/login
account  required  /lib64/security/pam_userdb.so  db=/etc/vsftpd/login
```

* **配置vsftpd主配置文件 （guest\_username=virtual 对应上面创建的用户）**

```bash
mv /etc/vsftpd/vsftpd.conf /etc/vsftpd/vsftpd.conf.bak
vim /etc/vsftpd/vsftpd.conf
#禁止匿名登录FTP服务器
anonymous_enable=NO
#允许本地用户登录FTP服务器
local_enable=YES
#可以上传(全局控制) 
write_enable=NO
#匿名用户可以上传
anon_upload_enable=NO
#匿名用户可以建目录
anon_mkdir_write_enable=NO
#匿名用户修改删除
anon_other_write_enable=NO
#全部用户被限制在主目录
chroot_local_user=YES

#2.3.5版本之后，如果用户被限定在了其主目录下，则该用户的主目录不能再具有写权限了，需新增加下面这条配置
allow_writeable_chroot=YES

#将所有用户看成虚拟用户guest
guest_enable=YES
#指定虚拟用户，也就是将guest用户映射到virtual用户
guest_username=virtual
#指定为独立服务
listen=YES
#指定监听的端口
listen_port=21
#开启被动模式
pasv_enable=YES

#FTP服务器公网IP
#pasv_address=<FTP服务器公网IP>

#设置被动模式下，建立数据传输可使用port范围的最小值
pasv_min_port=10000
#设置被动模式下，建立数据传输可使用port范围的最大值
pasv_max_port=10088
#是否允许匿名用户下载全局可读的文件
anon_world_readable_only=NO
#指定虚拟用户配置文件的路径
user_config_dir=/etc/vsftpd/user_conf


'''
anonymous_enable=NO
local_enable=YES
write_enable=NO
anon_upload_enable=NO
anon_mkdir_write_enable=NO
anon_other_write_enable=NO
chroot_local_user=YES
allow_writeable_chroot=YES
guest_enable=YES
guest_username=virtual
listen=YES
listen_port=21
pasv_enable=YES
pasv_min_port=10000
pasv_max_port=10088
anon_world_readable_only=NO
user_config_dir=/etc/vsftpd/user_conf
'''
```

* **创建上面配置文件中指定的子配置文件目录 user\_conf**

```bash
mkdir /etc/vsftpd/user_conf
```

* **定义testzhang用户的配置文件(注意：这里创建配置用户配置文件的文件名必须与上面创建的用户名一致)**

```bash
vim /etc/vsftpd/user_conf/testzhang
write_enable=YES
anon_world_readable_only=no
anon_upload_enable=YES
anon_mkdir_write_enable=YES
anon_other_write_enable=YESanon_umask=022
local_root=/data/ftp/zhang
```

#### **启动vsftpd**

```bash
systemctl restart vsftpd
```
