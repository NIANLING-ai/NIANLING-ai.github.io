---
title: 编译安装PHP7.4
date: 2024-01-16 09:25:00
updated: 2024-01-16 09:25:00
tags: [Linux, PHP]
excerpt: 十分详细的PHP编译安装过程，红帽系列机器，亲测无坑
categories: [Linux, PHP]
---

# 编译安装PHP7.4
## 依赖环境准备

* 下载安装编译工具

```bash
yum groupinstall 'Development Tools' -y
```

* 安装依赖包，否则可能会报错

```bash
yum update -y
yum install zlib-devel -y
yum install libxml2-devel -y
yum install libcurl-devel -y
yum install openssl-devel -y
yum install libjpeg-devel -y
yum install libpng-devel -y
yum install freetype-devel -y
yum install libpq-devel -y


yum install bzip2-devel -y
yum install sqlite-devel -y
yum install libcurl-devel -y
yum install libpng-devel -y
yum install automake -y
yum install autoconf -y
yum install libtool -y
yum install libicu-devel -y
yum install gmp-devel -y
yum install libzip-devel -y
yum -y install postgresql-devel

#报错：configure: error: Cannot find ldap.h 
yum install openldap.i686 -y
yum install openldap-devel.i686 -y
yum install openldap-devel -y

#遇到oniguruma的报错，要安装6.9以上版本的才行
wget https://github.com/kkos/oniguruma/releases/download/v6.9.8/onig-6.9.8.tar.gz
tar -xzvf oniguruma-6.9.4.tar.gz && cd oniguruma-6.9.4
./autogen.sh && ./configure --prefix=/usr
make && make install

##较低版本的系统，libzip是低版本的，要安装高版本libzip
yum install bzip2-devel
wget https://libzip.org/download/libzip-1.7.3.tar.gz
tar -xvzf libzip-1.7.3.tar.gz 
cd libzip-1.7.3
cmake -DCMAKE_INSTALL_PREFIX=/usr/libs
make && make install

export PKG_CONFIG_PATH=/usr/libs/lib64/pkgconfig:$PKG_CONFIG_PATH
```

## 安装流程

* 下载php7.4源码与安装

```bash
[root@rocky1 src]# cd /usr/local/src && wget https://www.php.net/distributions/php-7.4.30.tar.gz
[root@rocky1 src]# tar xzvf php-7.4.30.tar.gz && cd php-7.4.30

#创建用户
useradd -r php -s /sbin/nologin


#在php-7.4.30目录下预编译
./configure --prefix=/apps/php --with-fpm-user=php --with-fpm-group=php  --with-curl --enable-gd --enable-sockets --enable-bcmath --with-ldap --enable-gettext --enable-mbstring --with-openssl --with-zip --with-zlib  --enable-fpm --with pgsql=/apps/postgresql --with-pdo-pgsql=/apps/postgresql/bin/pg_config --with-gd --with-jpeg --with-freetype

#不指定路径
./configure --with-fpm-user=php --with-fpm-group=php  --with-curl --enable-gd --enable-sockets --enable-bcmath --with-ldap --enable-gettext --enable-mbstring --with-openssl --with-zip --with-zlib  --enable-fpm --with-pgsql --with-pdo-pgsql --with-gd --with-jpeg --with-freetype --with-mysqli --with-pdo-mysql

export PKG_CONFIG_PATH=/usr/lib/pkgconfig:/usr/libzip/lib64/pkgconfig ONIG_CFLAGS="-I/usr/include" ONIG_LIBS="-L/usr/lib -lonig"


#8.29版本的
./configure --prefix=/apps/php --with-fpm-user=php --with-fpm-group=php --with-curl --with-gd --with-jpeg --with-freetype --enable-sockets --enable-bcmath --with-ldap --enable-gettext --enable-mbstring --with-openssl --with-zip --with-zlib --enable-fpm --with-pgsql=/apps/postgresql --with-pdo-pgsql=/apps/postgresql/bin/pg_config


#编译
make && make install

chown -R php.php /apps/php
```

* 复制PHP配置文件模板

```bash
cp /usr/local/src/php-7.4.30/php.ini-development /apps/php/lib/php.ini
```

### 添加全局变量

* 1.打开终端，并以root权限登录
* 2.编辑/etc/profile文件，可以使用文本编辑器（如vi或nano）进行编辑：

```bash
#最后一行添加
[root@rocky1 src]# vim /etc/profile
export PATH="/apps/php/bin:$PATH"
```

* 3.重启配置生效

```bash
source /etc/profile
```

* 4.确认PHP命令是否可以全局使用

```bash
[root@rocky1 php]# php -v
PHP 7.4.30 (cli) (built: Aug 14 2023 09:37:56) ( NTS )
Copyright (c) The PHP Group
Zend Engine v3.4.0, Copyright (c) Zend Technologies
```

### systemctl管理PHP

* 创建一个名为php-fpm.service的服务单元文件

```bash
[root@rocky1~]# vim /etc/systemd/system/php-fpm.service
[Unit]
Description=PHP-FPM FastCGI Process Manager
[Service]
ExecStart=/apps/php/sbin/php-fpm --nodaemonize --fpm-config /apps/php/etc/php-fpm.conf
ExecReload=/bin/kill -USR2 $MAINPID
[Install]
WantedBy=multi-user.target


几个小坑：
1./apps/php/etc/php-fpm.conf配置文件名字必须为conf结尾的，默认的是php-fpm.conf.default，需要手动修改
2./apps/php/etc/php-fpm.d目录下的www.conf.default文件也需要修改成www.conf
```

* 启用并启动PHP-FPM服务

```bash
systemctl enable php-fpm
systemctl start php-fpm
```

* 在/apps/php/etc/php-fpm.d目录下的www.conf里添加以下行

```bash
php_admin_value[php.ini] = /apps/php/lib/php.ini
```

* 重启生效

```bash
systemctl restart php-fpm
```

* `www.conf`文件中的参数优化

```bash
#
pm = dynamic
```