---
title: iops查看
date: 2024-01-11 09:25:00
updated: 2024-01-11 12:00:00
tags: [磁盘读写,iops]
excerpt: 查看磁盘的性能的一些命令
categories: [Linux, iops]
---
# IOPS查看

### iostat命令

```bash
#每隔5秒执行一次iostat，连续执行3次
iostat -xmtc 5 3
Linux 3.10.0-1160.92.1.el7.x86_64 (zhang)       10/17/2023      _x86_64_        (2 CPU)

10/17/2023 08:19:03 PM
avg-cpu:  %user   %nice %system %iowait  %steal   %idle
           0.62    0.00    0.24    0.05    0.00   99.09

Device:         rrqm/s   wrqm/s     r/s     w/s    rMB/s    wMB/s avgrq-sz avgqu-sz   await r_await w_await  svctm  %util
vda               0.00     1.65    0.10    4.11     0.00     0.04    19.24     0.00    0.61    2.36    0.57   0.63   0.27

– 设备（设备的名称）
– rrqm/s（每秒钟进行的读操作的合并请求数）
– wrqm/s（每秒钟进行的写操作的合并请求数）
– r/s（每秒钟的读请求次数）
– w/s（每秒钟的写请求次数）
– rkB/s（每秒钟的读取数据量，单位KB）
– wkB/s（每秒钟的写入数据量，单位KB）
– avgrq-sz（每个请求的平均扇区数）
– avgqu-sz（平均I / O请求数量）
– awt（平均处理时间）
– svctm（平均服务时间）
– %util（每秒已使用磁盘时间的百分比）
```

### dstat命令

dstat是一个系统资源统计工具，它能轻松监视系统的IOPS。它还可以报告CPU使用率、内存和磁盘使用率等更多指标。想要使用dstat，请使用以下命令：

```bash
[root@zhang ~]# dstat -cdD total --disk-util --disk-tps --top-io-adv
Module dstat_disk_util failed to load. (No counter objects to monitor)
----total-cpu-usage---- -dsk/total- -dsk/total- -------most-expensive-i/o-process-------
usr sys idl wai hiq siq| read  writ|reads writs|process              pid  read write cpu
  1   0  99   0   0   0|2341B   38k|   0     4 |php-fpm: master proce31398  69k 199B0.0%
  1   1  99   0   0   0|   0  8192B|   0     2 |postgres: zabbix zabb18738   0 8192B  0%
  1   0  99   0   0   0|   0    12k|   0     3 |postgres: zabbix zabb18747   0 8192B  0%
  1   1  99   0   0   0|   0    32k|   0     4 |postgres: zabbix zabb18736   0 8192B  0%
  1   0  99   0   0   0|   0    12k|   0     3 |postgres: zabbix zabb18738   0 8192B  0%
  1   1  99   0   0   0|   0    24k|   0     4 |postgres: zabbix zabb18735   0   16k  0%
  1   1  99   0   0   0|   0  8192B|   0     2 |postgres: zabbix zabb18736   0 8192B  0%
  1   1  99   0   0   0|   0    16k|   0     3 |postgres: zabbix zabb18747   0 8192B  0%
  1   0  98   0   0   0|   0    56k|   0     4 |postgres: zabbix zabb18738   0 8192B  0%
  1   1  98   0   0   0|   0  8192B|   0     2 |postgres: zabbix zabb18735   0 8192B  0%
  1   0  99   0   0   0|   0  8192B|   0     2 |postgres: zabbix zabb18671   0 8192B  0%
  2   1  98   0   0   0|   0   396k|   0     7 |postmaster           1314  550k   0   0%
  1   1  99   0   0   0|   0    76k|   0    15 |node                 4925   11k  24k1.0%
  2   0  98   0   0   0|   0    84k|   0     2 |zabbix_agentd: collec130521258B   0   0%
 15   2  82   2   0   0|7280k  144k| 223     8 |containerd-shim-runc-4875  105k  47k  0%^C
```