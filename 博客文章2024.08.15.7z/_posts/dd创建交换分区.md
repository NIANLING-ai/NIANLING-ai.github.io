---
title: 使用dd命令管理swap
date: 2024-06-25 09:25:00
updated: 2024-06-25 09:25:00
tags: [Linux]
excerpt: 创建扩展或者缩减swap分区
categories: [Linux]
---
## 使用dd命令创建swap

### 默认开始没有交换分区

- 生成一个8GB大小的交换文件

```bash
sudo dd if=/dev/zero of=/swapfile bs=1G count=8
```

- 限制交换文件的访问权限，仅允许文件所有者读写

```bash
sudo chmod 600 /swapfile
```

- 将文件设置为交换空间

```bash
sudo mkswap /swapfile
```

- 启用交换文件作为虚拟内存

```bash
sudo swapon /swapfile
```

- 加入开机启动配置文件

```bash
sudo echo "/swapfile swap swap defaults 0 0" >> /etc/fstab
```

- 检验一下是否成功

```bash
sudo swapon -s
```

### 扩展交换分区

#### 涉及原有分区

使用 dd 命令创建的 swap 分区无法直接扩展。需要先关闭现有的 swap 分区，删除 swap 文件，再创建一个更大的 swap 文件，最后再启用它。

**小例子：如何将 8G 的 swap 分区扩展到 12G ?**

- 停用现有 swap 分区：

```bash
sudo swapoff /swapfile
```

- 删除旧的 swap 文件：

```bash
sudo rm /swapfile
```

- 创建新的 12G swap 文件：

```bash
sudo dd if=/dev/zero of=/swapfile bs=1G count=12
```

- 设置文件权限和属性：

```bash
sudo chmod 600 /swapfile
sudo mkswap /swapfile
```

- 启用新的 swap 分区：

```bash
sudo swapon /swapfile
```

- 更新 /etc/fstab 文件：

```bash
sudo sed -i 's/^\/swapfile.*/\/swapfile swap swap defaults 0 0/' /etc/fstab
```

- 验证 swap 分区是否已启用：

```bash
sudo swapon -s
```

#### 不涉及原有分区

- 查看所有交换分区

```bash
swapon --show
```

- 直接创建一个新的交换文件

```bash
sudo dd if=/dev/zero of=/mnt/newswapfile bs=1M count=2048
```

- 开启交换分区

```bash
sudo mkswap /mnt/newswapfile
```

- 激活

```bash
sudo swapon /mnt/newswapfile
```

- 确认

```bash
swapon --show
```

- 持久化

```bash
echo '/mnt/newswapfile none swap sw 0 0' >> /etc/fstab
```

- 看下实际可用有多少

```bash
free -h
```

### 缩减swap分区(文件形式的)

- 首先，关闭正在使用的 Swap 分区：
```bash
sudo swapoff -v /swapfile #（将 `/swapfile` 替换为您实际的 Swap 分区路径）
```
- 然后，删除或调整 Swap 文件的大小。如果是文件形式的 Swap，您可以使用 `truncate` 命令来调整大小
```bash
sudo truncate -s <new_size> /swapfile #（`<new_size>` 为您期望的新大小）
```

- 重新格式化并启用调整后的 Swap 分区：
```bash
sudo mkswap /swapfile
sudo swapon /swapfile
```