---
title: Nginx配置防盗链
date: 2024-05-16 09:25:00
updated: 2024-05-16 09:25:00
tags: [Nginx]
excerpt: Nginx配置防盗链
categories: [Nginx]
---
# Nginx配置防盗链
## 概述
```
防盗链其实就是防止别的站点来引用你的资源, 占用你的流量
```
在了解``nginx`` 防盗链之前先了解一下什么是HTTP的头信息`Referer`,当浏览器访问网站的时候,一般会带上`Referer`,告诉后端该是从哪个页面过来的。
`nginx`的防盗链功能基于`HTTP`协议的`Referer`机制,通过判断`Referer`对来源进行 识别和判断作出一定的处理
`nginx`会通就过查看`referer`自动和`valid_referers`后面的内容进行匹配，如果匹配到了就将`invalid_referer` 变量置为1 ,如果没有匹配到 ， 则将`invalid_referer`变量置为0 , 匹配的过程中不区分大小写。

## 一、配置盗链网站

- 1.启动一台``nginx``虚拟机，配置两个网站

```bash
vim /etc/nginx/conf.d/vhosts.conf
```

添加以下内容

```bash
server {
    listen 80;
    server_name site1.test.com;
    root /var/wwwroot/site1;
    index index.html;

    location / {
    }
}

server {
    listen 80;
    server_name site2.test.com;
    root /var/wwwroot/site2;
    index index.html;

    location / {
    }
}
```

-  2.在宿主机(windowns)编辑`C:\Windows\System32\drivers\etc\hosts`文件

```bash
192.168.147.10      site1.test.com
192.168.147.10      site2.test.com
```

-  3.创建网站根目录

```bash
mkdir /var/wwwroot
cd /var/wwwroot
mkdir site1
mkdir site2
echo -e "<h1>site1</h1><img src='1.jpg'>" >> site1/index.html
echo -e "<h1>site2</h1><img src='http://site1.test.com/1.jpg'>" >> site2/index.html
```

-  4.将`1.jpg`上传到`/var/wwwroot/site1`目录

-  5.启动`nginx`服务

```bash
systemctl restart nginx
netstat -anpt | grep nginx
```
-  6.防火墙放通80端口（我默认关闭防火墙）

```bash
setenforce 0
firewall-cmd --zone=public --add-port=80/tcp --permanent
firewall-cmd --reload
```

-  7.在宿主机访问

`http://site1.test.com`

<img src="https://img-130165.oss-cn-shanghai.aliyuncs.com/img/PixPin_2024-05-31_14-26-36.png" alt="PixPin_2024-05-31_14-26-36" style="zoom:80%;" />

`http://site2.test.com`

<img src="https://img-130165.oss-cn-shanghai.aliyuncs.com/img/image-20240531142947372.png" alt="image-20240531142947372" style="zoom:80%;" />


## 二、配置site1.test.com防盗链

-  1.编辑``nginx``配置文件

```bash
server {
    listen 80;
    server_name site1.test.com;
    root /var/wwwroot/site1;
    index index.html;

    location / {
    }

    location ~ \.(jpg|png|gif|jpeg)$ {
        valid_referers site1.test.com;
        if ($invalid_referer) {
            return 403;
        }
    }
}

server {
    listen 80;
    server_name site2.test.com;
    root /var/wwwroot/site2;
    index index.html;

    location / {
    }
}

#valid_referers site1.test.com;:这条指令检查请求来源，即用户从哪个页面跳转过来。这里只允许 site1.test.com 作为有效来源。
#if ($invalid_referer) { return 403; }: 如果来源不是 site1.test.com，则返回 403 禁止访问的错误。
```

-  2.重启``nginx``服务

```bash
systemctl restart nginx
```
-  3.在宿主机访问

清除浏览器缓存，访问`http://site2.test.com`

![image-20240531143239151](https://img-130165.oss-cn-shanghai.aliyuncs.com/img/image-20240531143239151.png)

*可见，防盗链配置起到了作用*

## 三、配置防盗链返回其他资源

-  1.编辑``nginx``配置文件

增加一个虚拟主机，对防盗链保护的资源进行重写

```bash
server {
    listen 80;
    server_name site1.test.com;
    root /var/wwwroot/site1;
    index index.html;
    location / {
    }
    location ~ \.(jpg|png|gif|jpeg)$ {
        valid_referers site1.test.com;
        if ($invalid_referer) {
            rewrite ^/ http://site3.test.com/notfound.jpg;
            #return 403;
        }
    }
}
server {
    listen 80;
    server_name site2.test.com;
    root /var/wwwroot/site2;
    index index.html;
    location / {
    }
}
server {
    listen 80;
    server_name site3.test.com;
    root /var/wwwroot/site3;
    index index.html;
    location / {
    }
}
```

**解释**

`location ~ \\.(jpg|png|gif|jpeg)$ {}`为设置防盗链的文件类型，使用竖线`|`分隔。`valid\_referers site1.test.com \*.`nginx`.org;`为白名单，使用空格分隔，可以使用`\*`进行泛域名设置。`if ($invalid\_referer) {}`为判断是否符合白名单，不符合白名单将执行{}内的内容。`rewrite ^/ http://site3.test.com/notfound.jpg;`为重写资源，如果不合符白名单，则重写为该地址。`return 403;`代表返回的状态码为403。

-  2.建立`site3`根目录

```bash
cd /var/wwwroot
mkdir site3
echo -e "<h1>site3</h1><img src='notfound.jpg'>" >> site3/index.html
```

-  3.上传`notfound.jpg`文件至`/var/wwwroot/site3`目录

-  4.重启``nginx``服务

```bash
systemctl restart nginx
```

-  5.在宿主机编辑`C:\Windows\System32\drivers\etc\hosts`文件

增加对`site3.test.com`的映射

```bash
192.168.147.10      site1.test.com
192.168.147.10      site2.test.com
192.168.147.10      site3.test.com
```

-  6.在宿主机访问`http://site2.test.com`

![image-20240531145409607](https://img-130165.oss-cn-shanghai.aliyuncs.com/img/image-20240531145409607.png)

可以看到，在`site2`中盗用的`site1`的`1.jpg`文件，被重定向到了`site3`上的`notfound.jpg`文件

