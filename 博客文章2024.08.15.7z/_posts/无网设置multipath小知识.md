---
title: 无网设置multipath多路径
date: 2023-12-16 09:25:00
updated: 2023-12-16 09:25:00
tags: [运维, 教程]
excerpt: 机房服务器无网的情况下，设置多路径
categories: [教程]
---

# 无网设置multipath小知识

```bash
#查看一下镜像有没有连接，这里是sr0
lsblk -l

mkdir /mnt/redhat
mount -t iso9660 /dev/sr0 /mnt/redhat

vim /etc/yum.repos.d/local.repo
[local]
name=Local Repository 
baseurl=file:///mnt/redhat
enabled=1 
gpgcheck=0
```
```bash
yum install device-mapper-multipath -y
```