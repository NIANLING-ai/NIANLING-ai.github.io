---
title: 编译安装Postgresql13.7
date: 2024-01-20 09:25:00
updated: 2024-01-20 09:25:00
tags: [Linux, Postgresql]
excerpt: 红帽系列的机器应该都大同小异
categories: [Linux, Postgresql]
---

# 编译安装Postgresql13.7

### 创建postgres用户及安装目录

```bash
# useradd postgres
# mkdir -p /apps/postgresql
```

### 安装PostgreSQL依赖包

```bash
yum install perl-ExtUtils-Embed -y
yum install readline-devel -y
yum install python-devel -y
yum install python3 -y
yum install python3-devel -y&nbsp;
yum install gcc-c++ -y
yum install cmake -y
yum install libarchive -y
yum install openssl-devel -y
```

### 部署PostgreSQL

```bash
##下载安装包
wget https://ftp.postgresql.org/pub/source/v13.7/postgresql-13.7.tar.gz  
tar -zxvf postgresql-13.7.tar.gz  ##解压安装包
cd postgresql-13.7/
./configure --prefix=/apps/postgresql --with-python --with-perl --with-openssl
make && make install

##查看已经安装成功
[root@rocky1 postgresql-13.7]# /apps/postgresql/bin/pg_ctl --version
pg_ctl (PostgreSQL) 13.7
```

### 配置环境变量

```bash
mkdir -p /apps/postgresql/pgdata ##创建数据库的数据目录
cat >> /etc/profile << EOF
### postgres ###
export PATH=/apps/postgresql/bin:$PATH
export LD_LIBRARY_PATH=/apps/postgresql/lib
export PGDATA=/apps/postgresql/pgdata
EOF

source /etc/profile

pg_ctl --version  ##环境变量配置成功
```

给用户目录赋权并创建数据库簇

```bash
chown -R postgres.postgres /apps/postgresql  ##修改postgresql所属组和所属用户
su - postgres
initdb  ##初始化数据库
```

### 后续配置

#### 自定义开放访问的IP ,修改data目录下的pg\_hba.conf文件

```bash
cd /apps/postgresql/pgdata
[root@rocky1 pgdata]# vim pg_hba.conf
# IPv4 out connections:
host    all             all             0.0.0.0/0                md5
```

#### 添加主机ip和主机名

```bash
[root@rocky1 pgdata]# vim postgresql.conf
listen_addresses = '*'          # what IP address(es) to listen on;
port = 5432 
```

* 切换到root用户，并到postgresql源码包的解压目录下(/root/postgresql-13.7/)

```bash
mkdir -p /apps/postgresql/log
cd /apps/postgresql/log
touch server.log
chown -R postgres.postgres log
#在/root/postgresql-13.7/contrib/start-scripts里面
'''
将 PostgreSQL 的启动脚本从源码包的 contrib/start-scripts/linux 目录复制到 /etc/init.d 目录中。这个脚本是用于启动、停止和管理 PostgreSQL 服务器的脚本。
'''
[root@rocky1 start-scripts]# cp linux /etc/init.d/postgresql
vim /etc/init.d/postgresql
prefix=/apps/postgresql
PGDATA="/apps/postgresql/pgdata"
PGLOG="/apps/postgresql/log/server.log"
```

* 赋予该文件执行权限

```bash
chmod +x /etc/init.d/postgresql
#设置服务开机自启
chkconfig --add postgresql

mkdir -p /home/postgres
chown -R postgres.postgres /home/postgres

#启动数据库
service postgresql restart
```

### 源码安装timesacledb

##### cmake需要3.0以上版本

```bash
wget&nbsp;https://github.com/Kitware/CMake/releases/download/v3.27.4/cmake-3.27.4.tar.gz

tar zxvf cmake-3.27.4.tar.gz
cd cmake-3.27.4
./bootstrap --prefix=/usr/local
make && make install
vi ~/.bash_profile
```

* 下载源码，或者直接下载包，传上去

```bash
wget https://github.com/timescale/timescaledb/archive/refs/tags/2.11.2.tar.gz
tar zxvf timescaledb-2.11.1.tar.gz
cd timescaledb-2.11.1
```

* 安装和编译

```bash
./bootstrap #如果有需要openssl就安装重新构建pgsql
cd ./build && make
make install

#加在最后一行
cd /apps/postgresql/pgdata
[root@rocky1 pgdata]# vim postgresql.conf
shared_preload_libraries = 'timescaledb'

service postgresql restart

CREATE DATABASE example;
\c example
CREATE EXTENSION IF NOT EXISTS timescaledb;
SELECT * FROM pg_extension WHERE extname='timescaledb';
```
