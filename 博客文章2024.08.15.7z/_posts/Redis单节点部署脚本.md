---
title: Redis单节点部署脚本
date: 2024-07-05 09:25:00
updated: 2024-07-18 09:25:00
tags: [Shell脚本]
excerpt: 一键部署Redis，单节点版本
categories: [Shell脚本]
---
###  Redis单节点部署脚本

```bash
#!/bin/bash

set -e

REDIS_VERSION="6.2.9"
REDIS_ID="6379"
INSTALL_DIR="/opt/app/redis"
install_dependencies() {
    yum -y install gcc gcc-c++ automake autoconf make tcl zlib-devel tar wget
}

create_redis_user() {
    useradd -s /sbin/nologin redis -M
}

modify_kernel_params() {
    cat >> /etc/sysctl.conf << EOF
net.ipv4.tcp_max_syn_backlog = 65535
net.core.somaxconn = 65535
net.ipv4.tcp_max_tw_buckets = 262144
net.ipv4.tcp_keepalive_intvl = 15
net.ipv4.tcp_keepalive_probes = 3
net.ipv4.tcp_keepalive_time = 120
vm.overcommit_memory = 1
vm.swappiness = 1
fs.file-max = 1024000
EOF
    sysctl -p
}

disable_thp() {
    echo 'never' > /sys/kernel/mm/transparent_hugepage/enabled
    echo 'never' > /sys/kernel/mm/transparent_hugepage/defrag

    cat >> /etc/rc.d/rc.local << EOF
if test -f /sys/kernel/mm/transparent_hugepage/enabled; then
    echo 'never' > /sys/kernel/mm/transparent_hugepage/enabled
fi
if test -f /sys/kernel/mm/transparent_hugepage/defrag; then
    echo 'never' > /sys/kernel/mm/transparent_hugepage/defrag
fi
EOF
}

modify_ulimit() {
    cat >> /etc/security/limits.conf << EOF
redis            soft    nofile          1024000
redis            hard    nofile          1024000
EOF
}

install_redis() {
    mkdir -p -v ${INSTALL_DIR}/{base,data,conf} ${INSTALL_DIR}/software
    cd ${INSTALL_DIR}/software/
    wget http://download.redis.io/releases/redis-${REDIS_VERSION}.tar.gz
    tar xf redis-${REDIS_VERSION}.tar.gz -C ${INSTALL_DIR}/base/
    cd ${INSTALL_DIR}/base
    mv redis-${REDIS_VERSION}/ ${REDIS_VERSION}

    cd ${INSTALL_DIR}/base/${REDIS_VERSION}/deps/
    make hiredis lua linenoise jemalloc

    cd ${INSTALL_DIR}/base/${REDIS_VERSION}/
    make -j$(nproc) && make install PREFIX=${INSTALL_DIR}/base/${REDIS_VERSION}

    chown -R redis.redis ${INSTALL_DIR}/
}

configure_redis() {
    mkdir -p -v ${INSTALL_DIR}/data/${REDIS_ID} ${INSTALL_DIR}/conf/${REDIS_ID}

    cat > ${INSTALL_DIR}/conf/${REDIS_ID}/redis_${REDIS_ID}.conf << EOF
### Server ###
pidfile                                   ${INSTALL_DIR}/data/${REDIS_ID}/redis_${REDIS_ID}.pid
port                                      ${REDIS_ID}
bind                                      0.0.0.0
logfile                                   "${INSTALL_DIR}/data/${REDIS_ID}/redis_${REDIS_ID}.log"
dbfilename                                dump_${REDIS_ID}.rdb
dir                                       ${INSTALL_DIR}/data/${REDIS_ID}
appendfilename                            "redis_${REDIS_ID}.aof"
daemonize                                 yes
loglevel                                  notice
databases                                 16
activerehashing                           yes
hz                                        10

### Auth ###
requirepass                               "123456"
masterauth                                "123456"

### Memory ###
maxmemory                                 10gb
maxmemory-policy                          noeviction
maxmemory-samples                         5

### Persistence ###
save                                      ""
#save                                      "900 1"
#save                                      "300 10"
#save                                      "60 10000"
stop-writes-on-bgsave-error               no
rdbcompression                            yes
rdbchecksum                               yes
appendonly                                yes
appendfsync                               everysec
no-appendfsync-on-rewrite                 yes
auto-aof-rewrite-percentage               100
auto-aof-rewrite-min-size                 2gb
aof-load-truncated                        yes

### Clients ###
maxclients                                10000
tcp-backlog                               65535
timeout                                   0
tcp-keepalive                             60
client-output-buffer-limit normal         0 0 0
client-output-buffer-limit slave          256mb 64mb 60
client-output-buffer-limit pubsub         32mb 8mb 60

### Replication ###
slave-serve-stale-data                    yes
slave-read-only                           yes
repl-diskless-sync                        no
repl-diskless-sync-delay                  5
repl-ping-slave-period                    10
repl-disable-tcp-nodelay                  no
repl-backlog-size                         2gb
repl-backlog-ttl                          3600
slave-priority                            100

### Command ###
rename-command                            flushall ""
rename-command                            flushdb ""

### Slowlog ###
slowlog-log-slower-than                   1000
slowlog-max-len                           1024

### Redis 4.0 New ###
lazyfree-lazy-eviction                    no
lazyfree-lazy-expire                      yes
lazyfree-lazy-server-del                  yes
slave-lazy-flush                          yes

### Redis Cluster ###
cluster-config-file                     nodes-${REDIS_ID}.conf
cluster-enabled                         yes
cluster-node-timeout                    15000
cluster-slave-validity-factor           10
cluster-migration-barrier               1
cluster-require-full-coverage           no
EOF

    chown -R redis.redis ${INSTALL_DIR}/
}

create_redis_service() {
    cat > /etc/systemd/system/redis_${REDIS_ID}.service << EOF
[Unit]
Description=Redis
After=syslog.target network.target remote-fs.target nss-lookup.target

[Service]
Type=forking
PIDFile=${INSTALL_DIR}/data/${REDIS_ID}/redis_${REDIS_ID}.pid
ExecStart="${INSTALL_DIR}/base/${REDIS_VERSION}/bin/redis-server" "${INSTALL_DIR}/conf/${REDIS_ID}/redis_${REDIS_ID}.conf"
ExecReload=/bin/kill -s HUP \$MAINPID
ExecStop=/bin/kill -s QUIT \$MAINPID
User=redis
Group=redis
PrivateTmp=true
ExecStartPost=/bin/sleep 2

[Install]
WantedBy=multi-user.target
EOF

    systemctl daemon-reload
    systemctl start redis_${REDIS_ID}.service
    systemctl enable redis_${REDIS_ID}.service
    systemctl status redis_${REDIS_ID}.service
    ln -s ${INSTALL_DIR}/base/${REDIS_VERSION}/bin/redis-cli /usr/bin/redis-cli
}

main() {
    install_dependencies
    create_redis_user
    modify_kernel_params
    disable_thp
    modify_ulimit
    install_redis
    configure_redis
    create_redis_service

    echo "Redis installation and configuration completed."
}

main
```

