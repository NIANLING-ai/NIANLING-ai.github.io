---
title: Linux计划任务
date: 2024-03-01 09:25:00
updated: 2024-03-01 09:25:00
tags: [Linux]
excerpt: crontab计划任务，定时执行，解放双手
categories: [Linux]
---
## Linux计划任务
- 可以预览计划任务的网站

[Crontab.guru - The cron schedule expression generator](https://crontab.guru/#5_4_*_*_*)

### 1、什么是计划任务

> 简单来说，就是某些我们需要定时执行的任务，可以是某条命令，也可以是某个脚本。

### 2、计划任务使用场景
```bash
1.按天进行日志切割
2.定时同步互联网时间
3.每天备份数据库数据
4.定时删除不需要的日志文件或临时文件
5.定时获取系统的状态信息
```
### 3、计划任务设置

#### 3.1 计划任务配置文件

Linux中最常用的计划任务服务为crond服务，该服务可以设置计划周期性的定时运行某些命令或脚本。

**计划任务配置文件：**
```bash
/etc/crontab        //crond计划任务列表配置文件
/etc/cron.deny      //该文件中所写用户无法使用crond计划任务
/var/spool/cron/*   //用户计划任务文件都存放此目录，文件以用户名命名
/var/log/cron       //定时任务执行后的日志文件
```
#### 3.2 计划任务配置

crond计划任务服务提供了crontab命令来创建和管理计划任务。
```bash
crontab [选项]

命令选项：
-e      //编辑当前用户计划任务文件
-l      //查看当前用户计划任务文件内容
-r      //删除当前用户计划任务文件内容
-u      //管理其他用户的计划任务

注意: crontab命令实际上就是在操作/var/spool/cron/username。
```

**计划任务书写格式：参考/etc/crontab配置文件中的格式**
```bash
.---------------- minute (0 - 59) //分钟
|  .------------- hour (0 - 23)   //小时
|  |  .---------- day of month (1 - 31)   //日期
|  |  |  .------- month (1 - 12) OR jan,feb,mar,apr //月份
|  |  |  |  .---- day of week (0 - 6) (Sunday=0 or 7) OR sun,mon,tue,wed,thu,fri,sat  //星期
|  |  |  |  |
*  *  *  *  *   user-name  command to be executed
分 时 日 月 周

*	//表示每，任意(分、时、日、月、周)时间都执行
*/	//表示每隔；例如：*/10 每隔10分钟
-	//表示时间范围段；例如：5-7点 5点到7点
,	//表示和, 例如：4,6,0 周四、周六和周日
```
#### 3.3 计划任务时间练习
```bash
* * * * *	//每分钟都执行
0 0 * * *	//每天0点执行
30 1 * * *	//每天凌晨1点30分执行
0 * * * *	//每小时执行
0 */2 * * *	//每隔两小时执行
*/30 * * * *	//每隔30分钟执行
0 1 15 * *	//每月的15号凌晨1点钟执行
0 5 1-14 * *	//每月1号-14号凌晨5点钟执行
0 6-8 */5 * *	//每隔5天的上午6点-8点整执行
0 20-23/1 * * *	//每天晚上8点-11点之间，每隔1小时执行
0 23 * * 1-3	//周一到周三每天晚上11点整执行
```

#### 3.4 编写计划任务注意事项

```bash
//编写计划任务时务必添加该计划任务的注释信息
[root@localhost ~]# crontab -e
#print string "hello world"
*/5 * * * * /usr/bin/echo "hello world"

//在计划任务中执行命令，命令最好用绝对路径
//写入计划任务中的命令先拿到命令行执行一遍，看结果是否成功
[root@localhost ~]# crontab -e
#print string "hello world"
*/5 * * * * /usr/bin/echo "hello world"

//计划任务输出结果可用">"重定向到指定文件
[root@localhost ~]# crontab -e
#print string "hello world"
*/5 * * * * /usr/bin/echo "hello world" &> /dev/null
```

**计划任务流程规范：**
```bash
流程规范:
1.先在测试环境中实践，千万不要上来就用生产服务器；
2.先理解需求；
3.写入计划任务中的命令先拿到命令行执行一遍；
4.脚本需要先进行测试，测试脚本是否可以正常执行；
5.写入计划任务里的任务，可以先将任务时间间隔缩短，方便测试；
6.执行过程如果需要，强烈建议写进日志。
```
### 4、crontab计划任务示例
```bash
//每天凌晨3点备份系统中配置文件目录
[root@localhost ~]# crontab -e
#directory /etc/ backup
0 3 * * * /usr/bin/tar -zcf /root/etc_backup.tar.gz /etc/ &> /dev/null

//每天隔1小时获取系统负载情况，并将信息存放到日志文件中
[root@localhost ~]# vim systemload.sh
#!/bin/bash
/usr/bin/echo "$(date "+%Y-%m-%d %H:%M:%S") load average:$(/usr/bin/top -n 1 -b | /usr/bin/awk -F ':' 'NR==1 {print$5}')" &>> /root/systemload.log

[root@localhost ~]# chmod +x systemload.sh

[root@localhost ~]# crontab -e
#get system load information
0 */1 * * * /root/systemload.sh
```
### 5、crond计划任务调试

> 1. 调整任务每分钟执行, 检测是否是否正常, 有些任务不要频繁执行
> 2. 调整系统时间然后在检测任务, 生产不建议直接使用此方式
> 3. 执行脚本, 将脚本执行输出写入指定日志文件, 观察日志内容是否正常
> 4. 注意一些任务命令带来的问题echo “wangqing” >>/tmp/test.log &>/dev/null
> 5. 命令使用绝对路径, 防止无法找到命令导致定时任务执行故障
> 6. 查看/var/log/cron日志进行调试

建议: 将需要定期执行的任务写入脚本中, 建立/scripts目录统一存放脚本, 脚本中命令必须使用绝对路径,手动执行脚本检测输出是否正常, 然后将脚本加入计划任务测试, 测试后无问题将脚本输出写入对应的日志文件中即可。

计划任务添加步骤：

1. 手动执行保留执行命令的正确结果
2. 编写脚本
   * 脚本需要统一路径/scripts
   * 脚本开头建议填写注释信息, 包括执行时间、周期、任务
   * 脚本内容复制执行成功的命令至脚本文件中(减少每个环节出错几率)
   * 脚本内容尽可能的优化, 使用一些变量或使用简单的判断语句
   * 脚本执行的输出信息不要随意打印, 可以重定向至其他位置保留或丢入黑洞
3. 执行脚本
   * 使用bash执行, 防止脚本没有增加执行权限(/bin/bash)
   * 执行命令以及脚本成功后并复制该命令
4. 编写计划任务
   * 加上必要的注释信息, 人、时间、任务
   * 设定计划任务执行的周期
   * 加入执行脚本的命令
5. 调试计划任务
   * 增加任务频率测试、调整系统时间测试(不能用于生产)
   * 检查环境变量问题、检查crond服务产生日志进行排查
