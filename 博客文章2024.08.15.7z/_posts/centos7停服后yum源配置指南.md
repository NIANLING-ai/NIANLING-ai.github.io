---
title: CentOS7停服后yum源配置指南
date: 2024-08-05 09:25:00
updated: 2024-08-05 09:25:00
tags: [Linux]
excerpt: CentOS7停服后yum源配置指南
categories: [Linux]
---
# CentOS7停服后yum源配置指南
`CentOS7`已于2024年6月30日正式停服，停服后默认的yum源已全部404无法使用。
通过下载本文配置整理好的`CentOS7`系统源，可以有效解决默认源404异常问题，注意：本文仅适用于Centos7系统，请勿将本文用于其它版本系统。

### 1、备份旧的yum源

在`/etc/yum.repos.d/`目录下创建一个`bak`目录，再将`/etc/yum.repos.d/`中的`repo`源配置文件移动至`bak`目录中，当然如果您确定`/etc/yum.repos.d/`目录中的源配置没用，也可以将`/etc/yum.repos.d/`目录清空（`rm -f /etc/yum.repos.d/\*`）。

```bash
mkdir -p /etc/yum.repos.d/bakmv /etc/yum.repos.d/*.repo /etc/yum.repos.d/bak/
```

### 2、配置Centos7源（x86\_64架构）

这里整理了多个Centos7国内镜像的源，任选其一即可，在Centos7停服后，默认的源已从centos改成了centos-vault，这里所有的源都是二次配置修改过的。

提供curl命令下载方式，以及wget命令下载方式，任选其一。

阿里云源（curl方式）

```bash
curl -o /etc/yum.repos.d/Centos7-aliyun.repo https://mirrors.wlnmp.com/centos/Centos7-aliyun-x86_64.repo
```

阿里云源（wget方式）

```bash
wget https://mirrors.wlnmp.com/centos/Centos7-aliyun-x86_64.repo -P /etc/yum.repos.d/
```

网易源（curl方式）

```bash
curl -o /etc/yum.repos.d/Centos7-163.repo https://mirrors.wlnmp.com/centos/Centos7-163-x86_64.repo
```

网易源（wget方式）

```bash
wget https://mirrors.wlnmp.com/centos/Centos7-163-x86_64.repo -P /etc/yum.repos.d/
```

腾讯源（curl方式）

```bash
curl -o /etc/yum.repos.d/Centos7-tencent.repo https://mirrors.wlnmp.com/centos/Centos7-tencent-x86_64.repo
```

腾讯源（wget方式）

```bash
wget https://mirrors.wlnmp.com/centos/Centos7-tencent-x86_64.repo -P /etc/yum.repos.d/
```

中国科学技术大学源（curl方式）

```bash
curl -o /etc/yum.repos.d/Centos7-ustc.repo https://mirrors.wlnmp.com/centos/Centos7-ustc-x86_64.repo
```

中国科学技术大学源（wget方式）

```bash
wget https://mirrors.wlnmp.com/centos/Centos7-ustc-x86_64.repo -P /etc/yum.repos.d/
```

荆楚理工学院源（curl方式）

```bash
curl -o /etc/yum.repos.d/Centos7-jcut.repo https://mirrors.wlnmp.com/centos/Centos7-jcut-x86_64.repo
```

荆楚理工学院源（wget方式）

```bash
wget https://mirrors.wlnmp.com/centos/Centos7-jcut-x86_64.repo -P /etc/yum.repos.d/
```

清华源（curl方式）

```bash
curl -o /etc/yum.repos.d/Centos7-tuna.repo https://mirrors.wlnmp.com/centos/Centos7-tuna-x86_64.repo
```

清华源（wget方式）

```bash
wget https://mirrors.wlnmp.com/centos/Centos7-tuna-x86_64.repo -P /etc/yum.repos.d/
```

南阳理工学院源（curl方式）

```bash
curl -o /etc/yum.repos.d/Centos7-nyist.repo https://mirrors.wlnmp.com/centos/Centos7-nyist-x86_64.repo
```

南阳理工学院源（wget方式）

```bash
wget https://mirrors.wlnmp.com/centos/Centos7-nyist-x86_64.repo -P /etc/yum.repos.d/
```

附：x86\_64架构系统，Centos7-aliyun.repo配置文件内容

```bash
[base]
name=CentOS-$releasever - base - mirrors.aliyun.com
baseurl=http://mirrors.aliyun.com/centos-vault/centos/$releasever/os/$basearch/
enabled=1
gpgcheck=1
gpgkey=http://mirrors.aliyun.com/centos-vault/RPM-GPG-KEY-CentOS-7
 
[updates]
name=CentOS-$releasever - updates - mirrors.aliyun.com
baseurl=http://mirrors.aliyun.com/centos-vault/centos/$releasever/updates/$basearch/
enabled=1
gpgcheck=1
gpgkey=http://mirrors.aliyun.com/centos-vault/RPM-GPG-KEY-CentOS-7
 
[extras]
name=CentOS-$releasever - extras - mirrors.aliyun.com
baseurl=http://mirrors.aliyun.com/centos-vault/centos/$releasever/extras/$basearch/
enabled=1
gpgcheck=1
gpgkey=http://mirrors.aliyun.com/centos-vault/RPM-GPG-KEY-CentOS-7
 
[centosplus]
name=CentOS-$releasever - centosplus - mirrors.aliyun.com
baseurl=http://mirrors.aliyun.com/centos-vault/centos/$releasever/centosplus/$basearch/
enabled=0
gpgcheck=1
gpgkey=http://mirrors.aliyun.com/centos-vault/RPM-GPG-KEY-CentOS-7
 
[fasttrack]
name=CentOS-$releasever - fasttrack - mirrors.aliyun.com
baseurl=http://mirrors.aliyun.com/centos-vault/centos/$releasever/fasttrack/$basearch/
enabled=0
gpgcheck=1
gpgkey=http://mirrors.aliyun.com/centos-vault/RPM-GPG-KEY-CentOS-7

[atomic]
name=CentOS-$releasever - atomic - mirrors.aliyun.com
baseurl=http://mirrors.aliyun.com/centos-vault/centos/$releasever/atomic/$basearch/
enabled=0
gpgcheck=1
gpgkey=http://mirrors.aliyun.com/centos-vault/RPM-GPG-KEY-CentOS-7

[dotnet]
name=CentOS-$releasever - dotnet - mirrors.aliyun.com
baseurl=http://mirrors.aliyun.com/centos-vault/centos/$releasever/dotnet/$basearch/
enabled=0
gpgcheck=1
gpgkey=http://mirrors.aliyun.com/centos-vault/RPM-GPG-KEY-CentOS-7

[rt]
name=CentOS-$releasever - rt - mirrors.aliyun.com
baseurl=http://mirrors.aliyun.com/centos-vault/centos/$releasever/rt/$basearch/
enabled=0
gpgcheck=1
gpgkey=http://mirrors.aliyun.com/centos-vault/RPM-GPG-KEY-CentOS-7

[sclo-rh]
name=CentOS-$releasever - sclo-rh - mirrors.aliyun.com
baseurl=http://mirrors.aliyun.com/centos-vault/centos/$releasever/sclo/$basearch/rh/
enabled=0
gpgcheck=1
gpgkey=http://mirrors.aliyun.com/centos-vault/RPM-GPG-KEY-CentOS-7

[sclo-sclo]
name=CentOS-$releasever - sclo-sclo - mirrors.aliyun.com
baseurl=http://mirrors.aliyun.com/centos-vault/centos/$releasever/sclo/$basearch/sclo/
enabled=0
gpgcheck=1
gpgkey=http://mirrors.aliyun.com/centos-vault/RPM-GPG-KEY-CentOS-7
```

### 3、配置Centos7源（只要当前不是x86\_64架构的，都使用以下配置，适用于aarch64、i386、ppc64等）

阿里云源（curl方式）

```bash
curl -o /etc/yum.repos.d/Centos7-aliyun.repo https://mirrors.wlnmp.com/centos/Centos7-aliyun-altarch.repo
```

阿里云源（wget方式）

```bash
wget https://mirrors.wlnmp.com/centos/Centos7-aliyun-altarch.repo -P /etc/yum.repos.d/
```

网易源（curl方式）

```bash
curl -o /etc/yum.repos.d/Centos7-163.repo https://mirrors.wlnmp.com/centos/Centos7-163-altarch.repo
```

网易源（wget方式）

```bash
wget https://mirrors.wlnmp.com/centos/Centos7-163-altarch.repo -P /etc/yum.repos.d/
```

腾讯源（curl方式）

```bash
curl -o /etc/yum.repos.d/Centos7-tencent.repo https://mirrors.wlnmp.com/centos/Centos7-tencent-altarch.repo
```

腾讯源（wget方式）

```bash
wget https://mirrors.wlnmp.com/centos/Centos7-tencent-altarch.repo -P /etc/yum.repos.d/
```

中国科学技术大学源（curl方式）

```bash
curl -o /etc/yum.repos.d/Centos7-ustc.repo https://mirrors.wlnmp.com/centos/Centos7-ustc-altarch.repo
```

中国科学技术大学源（wget方式）

```bash
wget https://mirrors.wlnmp.com/centos/Centos7-ustc-altarch.repo -P /etc/yum.repos.d/
```

荆楚理工学院源（curl方式）

```bash
curl -o /etc/yum.repos.d/Centos7-jcut.repo https://mirrors.wlnmp.com/centos/Centos7-jcut-altarch.repo
```

荆楚理工学院源（wget方式）

```bash
wget https://mirrors.wlnmp.com/centos/Centos7-jcut-altarch.repo -P /etc/yum.repos.d/
```

清华源（curl方式）

```bash
curl -o /etc/yum.repos.d/Centos7-tuna.repo https://mirrors.wlnmp.com/centos/Centos7-tuna-altarch.repo
```

清华源（wget方式）

```bash
wget https://mirrors.wlnmp.com/centos/Centos7-tuna-altarch.repo -P /etc/yum.repos.d/
```

南阳理工学院源（curl方式）

```bash
curl -o /etc/yum.repos.d/Centos7-nyist.repo https://mirrors.wlnmp.com/centos/Centos7-nyist-altarch.repo
```

南阳理工学院源（wget方式）

```bash
wget https://mirrors.wlnmp.com/centos/Centos7-nyist-altarch.repo -P /etc/yum.repos.d/
```

附：Centos7-aliyun.repo配置文件内容（非x86\_64架构系统），配置文件通过$basearch变量自动识别系统架构。

```bash
[base]
name=CentOS-$releasever - base - mirrors.aliyun.com
baseurl=http://mirrors.aliyun.com/centos-vault/altarch/$releasever/os/$basearch/
enabled=1
gpgcheck=1
gpgkey=http://mirrors.aliyun.com/centos-vault/RPM-GPG-KEY-CentOS-7
 
[updates]
name=CentOS-$releasever - updates - mirrors.aliyun.com
baseurl=http://mirrors.aliyun.com/centos-vault/altarch/$releasever/updates/$basearch/
enabled=1
gpgcheck=1
gpgkey=http://mirrors.aliyun.com/centos-vault/RPM-GPG-KEY-CentOS-7
 
[extras]
name=CentOS-$releasever - extras - mirrors.aliyun.com
baseurl=http://mirrors.aliyun.com/centos-vault/altarch/$releasever/extras/$basearch/
enabled=1
gpgcheck=1
gpgkey=http://mirrors.aliyun.com/centos-vault/RPM-GPG-KEY-CentOS-7
 
[centosplus]
name=CentOS-$releasever - centosplus - mirrors.aliyun.com
baseurl=http://mirrors.aliyun.com/centos-vault/altarch/$releasever/centosplus/$basearch/
enabled=0
gpgcheck=1
gpgkey=http://mirrors.aliyun.com/centos-vault/RPM-GPG-KEY-CentOS-7
 
[fasttrack]
name=CentOS-$releasever - fasttrack - mirrors.aliyun.com
baseurl=http://mirrors.aliyun.com/centos-vault/altarch/$releasever/fasttrack/$basearch/
enabled=0
gpgcheck=1
gpgkey=http://mirrors.aliyun.com/centos-vault/RPM-GPG-KEY-CentOS-7

[atomic]
name=CentOS-$releasever - atomic - mirrors.aliyun.com
baseurl=http://mirrors.aliyun.com/centos-vault/altarch/$releasever/atomic/$basearch/
enabled=0
gpgcheck=1
gpgkey=http://mirrors.aliyun.com/centos-vault/RPM-GPG-KEY-CentOS-7

[dotnet]
name=CentOS-$releasever - dotnet - mirrors.aliyun.com
baseurl=http://mirrors.aliyun.com/centos-vault/altarch/$releasever/dotnet/$basearch/
enabled=0
gpgcheck=1
gpgkey=http://mirrors.aliyun.com/centos-vault/RPM-GPG-KEY-CentOS-7

[rt]
name=CentOS-$releasever - rt - mirrors.aliyun.com
baseurl=http://mirrors.aliyun.com/centos-vault/altarch/$releasever/rt/$basearch/
enabled=0
gpgcheck=1
gpgkey=http://mirrors.aliyun.com/centos-vault/RPM-GPG-KEY-CentOS-7

[sclo-rh]
name=CentOS-$releasever - sclo-rh - mirrors.aliyun.com
baseurl=http://mirrors.aliyun.com/centos-vault/altarch/$releasever/sclo/$basearch/rh/
enabled=0
gpgcheck=1
gpgkey=http://mirrors.aliyun.com/centos-vault/RPM-GPG-KEY-CentOS-7

[sclo-sclo]
name=CentOS-$releasever - sclo-sclo - mirrors.aliyun.com
baseurl=http://mirrors.aliyun.com/centos-vault/altarch/$releasever/sclo/$basearch/sclo/
enabled=0
gpgcheck=1
gpgkey=http://mirrors.aliyun.com/centos-vault/RPM-GPG-KEY-CentOS-7
```

### 4、清理缓存重建缓存

```bash
yum clean allyum makecache
```

此时CentOS7的yum源配置完成，可以像原来一样使用了。
