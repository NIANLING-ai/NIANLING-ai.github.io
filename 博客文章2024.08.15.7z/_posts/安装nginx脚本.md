---
title: install_nginx
date: 2024-03-12 09:25:00
updated: 2024-03-12 09:25:00
tags: [Shell脚本]
excerpt: 安装Nginx脚本，已测试ubuntu24和Rocky9.4无问题，其余系统继续测试中
categories: [Shell脚本]
---
## 安装Nginx
```bash
#!/bin/sh

# 设置Nginx版本和安装目录
NGINX_VERSION="1.24.0"
INSTALL_DIR="/opt/app/nginx-$NGINX_VERSION/"

# 解析OS ID
OS_ID=$(awk -F= '/^ID=/{gsub("\"", "", $2); print tolower($2)}' /etc/os-release)

# 检测并创建文件夹
check_and_create_directory() {
    if [ ! -d "$1" ]; then
        mkdir -p "$1"
        echo "创建文件夹 $1"
    else
        echo "文件夹 $1 已存在"
    fi
}

# 检查命令是否存在的函数
command_exists() {
    [ -x "$(command -v "$1")" ]
}

# 安装必要的软件
install_dependencies() {
    echo "正在检查并安装wget和tar，请稍等！"
    if [ "$OS_ID" = "centos" ] || [ "$OS_ID" = "rocky" ] || [ "$OS_ID" = "rhel" ]; then
        command_exists wget || yum -y install wget
        command_exists tar || yum -y install tar
        yum install -y gcc pcre-devel openssl-devel zlib-devel make
    elif [ "$OS_ID" = "ubuntu" ] || [ "$OS_ID" = "debian" ]; then
        command_exists wget || (apt-get update &>/dev/null && apt-get -y install wget &> /dev/null)
        command_exists tar || (apt-get update &>/dev/null && apt-get -y install tar &> /dev/null)
        apt-get install -y gcc libpcre3 libpcre3-dev zlib1g-dev libssl-dev make
    else
        echo "不支持的操作系统: $OS_ID"
        exit 1
    fi
}

# 检查解析的 OS_ID
echo "解析的操作系统 ID 是: $OS_ID"

# 创建Nginx用户
create_nginx_user() {
    if id -u nginx >/dev/null 2>&1; then
        echo "Nginx用户已经存在."
    else
        echo "创建Nginx用户..."
        useradd -r -s /sbin/nologin nginx
        echo "创建Nginx用户成功."
    fi
}

# 下载并编译安装Nginx
compile_nginx() {
    check_and_create_directory "$INSTALL_DIR"
    check_and_create_directory "/opt/src"
    wget http://nginx.org/download/nginx-$NGINX_VERSION.tar.gz -P /opt/src
    cd /opt/src
    tar -zxvf nginx-$NGINX_VERSION.tar.gz
    cd nginx-$NGINX_VERSION
    
    ./configure --prefix=$INSTALL_DIR \
                --user=nginx \
                --group=nginx \
                --with-http_ssl_module \
                --with-http_v2_module \
                --with-http_realip_module \
                --with-http_stub_status_module \
                --with-http_gzip_static_module \
                --with-pcre \
                --with-stream \
                --with-stream_ssl_module \
                --with-stream_realip_module

    make
    make install

    # 清理安装过程中的临时文件
    cd ..
    rm -rf nginx-$NGINX_VERSION
    rm nginx-$NGINX_VERSION.tar.gz

    chown -R nginx:nginx "$INSTALL_DIR"
}

# 创建Nginx服务启动脚本
create_systemd_service() {
    cat > /etc/systemd/system/nginx.service << EOF
[Unit]
Description=Nginx HTTP Server
After=network.target

[Service]
Type=forking
ExecStart=$INSTALL_DIR/sbin/nginx
ExecReload=$INSTALL_DIR/sbin/nginx -s reload
ExecStop=$INSTALL_DIR/sbin/nginx -s stop
PrivateTmp=true

[Install]
WantedBy=multi-user.target
EOF

    systemctl daemon-reload

    ln -s $INSTALL_DIR/sbin/nginx /usr/bin/nginx

    systemctl enable nginx
    systemctl start nginx
}

# 验证Nginx安装
verify_nginx_install() {
    nginx -v
    ln -s $INSTALL_DIR /opt/app/nginx
}

# 这里定义脚本的 main 函数
main() {
    # 临时输出系统路径信息用于调试
    #echo "System PATH: $PATH"
    #which nginx

    # 修改检查逻辑以更可靠地识别 nginx 是否存在
    if command_exists nginx; then
        echo "Nginx已经安装，跳过安装步骤"
        exit 0
    else
        echo "Nginx未安装，继续安装步骤"
    fi

    install_dependencies
    create_nginx_user
    compile_nginx
    create_systemd_service
    verify_nginx_install
}

main
```