---
title: Linux集群系统时间同步
date: 2024-01-24 09:25:00
updated: 2024-01-24 09:25:00
tags: [Linux, 进阶教程]
excerpt: Linux的集群时间同步配置，包括单台的做法
categories: [Linux, 进阶教程]
---

## Linux集群系统时间同步

环境准备：

- 服务器集群 我准备了2台虚拟机，主机名分别是server1、server3，操作系统版本为CentOS-7.9 
### 1.查看系统当前时间和时区

```bash
# 查看时间
[root@server1 ~]# date
Mon Feb 19 10:24:03 CST 2024

[root@server1 ~]# date -R # 显示时区
Mon, 19 Feb 2024 10:24:40 +0800

[root@server1 ~]# date '+%Y-%m-%d %H:%M:%S' # 按照指定格式显示日期时间
2024-02-19 10:25:06

# 查看时区
[root@server1 ~]# timedatectl | grep "Time zone"
       Time zone: Asia/Shanghai (CST, +0800)
```

### 2\. 修改时区

要做到服务器集群的时间同步，集群中各台机器的时区必须相同的，我们在国内就使用中国时区，如果你的机器的时区不是"Asia/Shanghai"，需要修改时区

CentOS 中时区是以文件形式存在，当前正在使用的时区文件位于

`/etc/localtime`，其他时区文件则位于`/usr/share/zoneinfo`下，中国时区的文件全路径是`/usr/share/zoneinfo/Asia/Shanghai`

#### (1) 如果系统中有`/usr/share/zoneinfo/Asia/Shanghai`这个文件

要更改时区，直接使用如下命令就OK

```none
cp /usr/share/zoneinfo/Asia/Shanghai /etc/localtime
```

#### (2) 如果没有 Asia/Shanghai 时区文件

需要使用 `tzselect` 命令去生成时区文件，生成好的时区文件就在/usr/share/zoneinfo 目录下，具体步骤去下：

-  <1> 执行tzselect命令

```bash
[root@server1 ~]# tzselect
Please identify a location so that time zone rules can be set correctly.
Please select a continent or ocean.
 1) Africa
 2) Americas
 3) Antarctica
 4) Arctic Ocean
 5) Asia
 6) Atlantic Ocean
 7) Australia
 8) Europe
 9) Indian Ocean
10) Pacific Ocean
11) none - I want to specify the time zone using the Posix TZ format.
#? 5 # 选亚洲
Please select a country.
 1) Afghanistan       18) Israel            35) Palestine
 2) Armenia       19) Japan         36) Philippines
 3) Azerbaijan        20) Jordan            37) Qatar
 4) Bahrain       21) Kazakhstan        38) Russia
 5) Bangladesh        22) Korea (North)     39) Saudi Arabia
 6) Bhutan        23) Korea (South)     40) Singapore
 7) Brunei        24) Kuwait            41) Sri Lanka
 8) Cambodia          25) Kyrgyzstan        42) Syria
 9) China         26) Laos          43) Taiwan
10) Cyprus        27) Lebanon           44) Tajikistan
11) East Timor        28) Macau         45) Thailand
12) Georgia       29) Malaysia          46) Turkmenistan
13) Hong Kong         30) Mongolia          47) United Arab Emirates
14) India         31) Myanmar (Burma)       48) Uzbekistan
15) Indonesia         32) Nepal         49) Vietnam
16) Iran          33) Oman          50) Yemen
17) Iraq          34) Pakistan
#? 9 # 选中国
Please select one of the following time zone regions.
1) Beijing Time
2) Xinjiang Time
#? 1 # 只能选择北京时间和新疆时间，但即使选择了北京时间，最后生成的也是上海时区的文件

The following information has been given:

    China
    Beijing Time

Therefore TZ='Asia/Shanghai' will be used.
Local time is now:  Thu Nov 23 04:44:37 CST 2017.
Universal Time is now:  Wed Nov 22 20:44:37 UTC 2017.
Is the above information OK?
1) Yes
2) No
#? 1 # 确认

You can make this change permanent for yourself by appending the line
    TZ='Asia/Shanghai'; export TZ
to the file '.profile' in your home directory; then log out and log in again.

Here is that TZ value again, this time on standard output so that you
can use the /usr/bin/tzselect command in shell scripts:
Asia/Shanghai # 很无奈，不是北京，但问题不大
```

- <2> 执行`cp /usr/share/zoneinfo/Asia/Shanghai /etc/localtime`这个命令

- <3> 执行`cat /etc/sysconfig/clock`命令验证，如果ZONE的值不是`Asia/Shanghai`，手动改为这个值，注意，不执行第<1>步直接手动修改是无效果的

### 3\. 集群时间同步方法一：手动修改

使用`date -s`命令来修改系统时间

```bash
[root@server1 ~]# date -s 12/25/2016
[root@server1 ~]# date -s 19:57:30
[root@server1 ~]# date -s "2024-02-19 13:50:30"

# 手动修改后，使用以下命令，把系统时间写入主板，这样，即使服务器关机或断电，时间也会更新
[root@server1 ~]# hwclock -w
```

让集群所有的服务器的时间同步，就用远程连接工具连接所有服务器，然后在所有的服务器中同时执行`date -s`命令设置时间，然后在所有的服务器中执行`hwclock -w`命令即可

### 4\. 集群时间同步方法二：自动同步网络时间(需要网络)

#### (1) 通过外网同步时间

```bash
[root@server1 ~]# ntpdate ntp.ntsc.ac.cn
# 或者
[root@server1 ~]# ntpdate 114.118.7.163
```

上海交通大学网络中心NTP服务器地址：ntp.sjtu.edu.cn（17.253.116.125）

中国国家授时中心服务器地址：ntp.ntsc.ac.cn（114.118.7.163）

若以上提供的网络时间服务器不可用，请自行上网寻找可用的网络时间服务器

#### (2)设置自动执行任务，定时更新时间

<1> 使用命令：`crontab -e`

```bash
[root@server1 ~]# crontab -e
```

<2> 然后往里加入一行内容

```bash
*/10 * * * * /usr/sbin/ntpdate ntp.ntsc.ac.cn
```

上面的配置表示，每隔十分钟从 `ntp.ntsc.ac.cn`该时间服务器同步一次时间。

<3> 保存退出

<4>确认是否执行成功，查看日志，寻找相关关键字

```bash
[root@server1 ~]# cat /var/log/cron |grep ntpdate
Feb 19 13:30:01 server1 CROND[12627]: (root) CMD (/usr/sbin/ntpdate ntp.ntsc.ac.cn)
Feb 19 13:40:01 server1 CROND[13120]: (root) CMD (/usr/sbin/ntpdate ntp.ntsc.ac.cn)

and

[root@server1 ~]# tail /var/spool/mail/root -n 20
id 2D1763C2F5; Mon, 19 Feb 2024 13:40:10 +0800 (CST)
From: "(Cron Daemon)" <root@server1.localdomain>
To: root@server1.localdomain
Subject: Cron <root@server1> /usr/sbin/ntpdate ntp.ntsc.ac.cn
Content-Type: text/plain; charset=UTF-8
Auto-Submitted: auto-generated
Precedence: bulk
X-Cron-Env: <XDG_SESSION_ID=19>
X-Cron-Env: <XDG_RUNTIME_DIR=/run/user/0>
X-Cron-Env: <LANG=en_US.UTF-8>
X-Cron-Env: <SHELL=/bin/sh>
X-Cron-Env: <HOME=/root>
X-Cron-Env: <PATH=/usr/bin:/bin>
X-Cron-Env: <LOGNAME=root>
X-Cron-Env: <USER=root>
Message-Id: <20240219054010.2D1763C2F5@server1.localdomain>
Date: Mon, 19 Feb 2024 13:40:10 +0800 (CST)

19 Feb 13:40:10 ntpdate[13120]: adjust time server 114.118.7.161 offset 0.084765 sec
```



#### (3) 说明

以上两步操作可以让server1这个服务器每隔10分钟去指定的服务器同步时间，如果需要让集群中的所有服务器时间同步，那么每台服务器都要做以上两步操作。

### 5\. 集群时间同步方法三：局域网内选一台服务器作为时间服务器，其他服务器从局域网内的时间服务器更新时间，同时局域网内的时间服务器向外网时间服务器同步时间

server1的IP为192.168.47.120，让它作为时间服务器，192.168.47.0局域网内的所有服务器都向它同步时间，而server1这台时间服务器本身，向外网时间服务器同步时间(比如中国国家授时中心服务器)

#### (1) 选择一台服务器作为NTP服务器

我用server1

```bash
[root@server1 ~]# yum install ntp -y
```



#### (2) 给局域网所有需要同步时间的服务器安装ntp服务

#### (3) 给所有的需要同步时间的机器(包括server1)设置ntp服务开机自启动，但不要启动服务

```bash
systemctl enable ntpd
```

#### (4) 修改server1的配置文件`/etc/ntp.conf`

我去掉了所有的默认注释，对其中的修改写了自己的注释，没有写注释的是默认配置

```bash
driftfile /var/lib/ntp/drift

restrict default nomodify notrap nopeer noquery

restrict 127.0.0.1 
restrict ::1

#注释掉默认的
#server 0.centos.pool.ntp.org iburst
#server 1.centos.pool.ntp.org iburst
#server 2.centos.pool.ntp.org iburst
#server 3.centos.pool.ntp.org iburst

server 0.asia.pool.ntp.org
server 1.asia.pool.ntp.org
server 2.asia.pool.ntp.org
server 3.asia.pool.ntp.org
或者
server ntp1.aliyun.com
server ntp2.aliyun.com
server ntp3.aliyun.com
server ntp4.aliyun.com
server ntp5.aliyun.com
或者
server ntp.ntsc.ac.cn

restrict 192.168.47.0 netmask 255.255.255.0 nomodify notrap

includefile /etc/ntp/crypto/pw

keys /etc/ntp/keys


disable monitor

# 同步时间后，写到硬件中
SYNC_HWCLOCK=yes
```

### (5) 启动ntpd服务之前，手动同步一下时间

因为ntpd服务开启之后，就不能手动同步时间了，那么为什么要先手动同步时间呢？

**当server(中国国家授时中心服务器)与client(server1)之间的时间误差过大时（可能是1000秒），server1去同步时间可能对系统和应用带来不可预知的问题，server1将停止时间同步！所以如果发现server1启动之后时间并不进行同步时，应该考虑到可能是时间差过大引起的，此时需要先手动进行时间同步！**

```bash
ntpdate ntp.ntsc.ac.cn
```



### (6) 启动server1的ntpd服务

```none
[root@server1 ~]# systemctl start ntpd.service
```

### (7) 检查ntp状态

```bash
[root@server1 ~]# systemctl status ntpd
● ntpd.service - Network Time Service
   Loaded: loaded (/usr/lib/systemd/system/ntpd.service; enabled; vendor preset: disabled)
   Active: active (running) since Mon 2024-02-19 14:02:57 CST; 42s ago
  Process: 1592 ExecStart=/usr/sbin/ntpd -u ntp:ntp $OPTIONS (code=exited, status=0/SUCCESS)
 Main PID: 1593 (ntpd)
   CGroup: /system.slice/ntpd.service
           └─1593 /usr/sbin/ntpd -u ntp:ntp -g

Feb 19 14:02:57 server1 ntpd[1593]: Listen and drop on 1 v6wildcard :: UDP 123
Feb 19 14:02:57 server1 ntpd[1593]: Listen normally on 2 lo 127.0.0.1 UDP 123
Feb 19 14:02:57 server1 ntpd[1593]: Listen normally on 3 ens33 192.168.47.120 UDP 123
Feb 19 14:02:57 server1 ntpd[1593]: Listen normally on 4 lo ::1 UDP 123
Feb 19 14:02:57 server1 ntpd[1593]: Listen normally on 5 ens33 fe80::20c:29ff:fe69:c8a0 UDP 123
Feb 19 14:02:57 server1 ntpd[1593]: Listening on routing socket on fd #22 for interface updates
Feb 19 14:02:57 server1 systemd[1]: Started Network Time Service.
Feb 19 14:03:02 server1 ntpd[1593]: 0.0.0.0 c016 06 restart
Feb 19 14:03:02 server1 ntpd[1593]: 0.0.0.0 c012 02 freq_set kernel 0.000 PPM
Feb 19 14:03:02 server1 ntpd[1593]: 0.0.0.0 c011 01 freq_not_set
```

### (7) 查看网络中的NTP服务器，显示客户端和每个服务器的关系

```bash
[root@server1 ~]# ntpq -p
     remote           refid      st t when poll reach   delay   offset  jitter
==============================================================================
 236.99.217.185. 192.114.63.250   3 u   53   64    3  329.852   16.259   3.229
 ntp.xtom.com.hk 118.143.17.83    2 u   54   64    1   65.072   11.479   0.000
 ntp5.mum-in.hos 36.224.68.195    2 u   54   64    3  236.350  -31.003 114.595
 ns2.ads.net.id  203.4.241.5      2 u   55   64    3  416.763  -20.510   2.412
```



这里的前4行就是我们配置的4个时间服务器的信息

```none
# 授时中心服务器地址
server 0.asia.pool.ntp.org
server 1.asia.pool.ntp.org
server 2.asia.pool.ntp.org
server 3.asia.pool.ntp.org
```

最后一行就是本地时间服务的信息

```none
# 外部时间服务器不可用时，以本地时间作为时间服务
server  127.127.1.0
fudge   127.127.1.0 stratum 10
```

下面对每个列的意义进行说明：

```bash
#remote地址前的符号：
`*`：响应的NTP服务器和最精确的服务器；
`+`：响应这个查询请求的NTP服务器；
`blank(什么都没有)`：没有响应的NTP服务器 
#说明： 
ntp服务启动后，一般需要5-10分钟左右的时候才能与外部时间服务器开始同步时间，所以需要等待几分钟才能看到正常的现象，否则你看到的是响应的NTP服务器和最精确的服务器是LOCAL(0)，最后一行前面是`*`符号，其他都是空白

-remote 响应这个请求的NTP服务器的名称
-refid NTP服务器使用的更高一级服务器的名称
-st 正在响应请求的NTP服务器的级别
-when 上一次成功请求之后到现在的秒数
-poll 本地和远程服务器多少时间进行一次同步，单位秒，在一开始运行NTP的时候这个poll值会比较小，服务器同步的频率大，可以尽快调整到正确的时间范围，之后poll值会逐渐增大，同步的频率也就会相应减小
-reach 用来测试能否和服务器连接，是一个八进制值，每成功连接一次它的值就会增加
-delay 从本地机发送同步要求到ntp服务器的往返时间
-offset 主机通过NTP时钟同步与所同步时间源的时间偏移量，单位为毫秒，offset越接近于0，主机和ntp服务器的时间越接近 
-jitter 统计了在特定个连续的连接数里offset的分布情况。简单地说这个数值的绝对值越小，主机的时间就越精确
```

### (8) 查看server1的ntp服务状态

```none
[root@server1 ~]# ntpstat
synchronised to NTP server (116.12.47.30) at stratum 3
   time correct to within 483 ms
   polling server every 64 s
```

同样，服务启动后需要等待5-10分钟才能看到这个正常的信息

到这里，我们局域网内的时间服务器server1就已经配置完毕了

### (9) 配置客户端向server1同步时间

#### <1> 修改每台客户端的`/etc/ntp.conf`配置文件

文件内容如下：

同样，没有写注释的都是默认的配置

```bash
driftfile /var/lib/ntp/drift

restrict default nomodify notrap nopeer noquery

restrict 127.0.0.1 
restrict ::1

#注释掉默认的
#server 0.centos.pool.ntp.org iburst
#server 1.centos.pool.ntp.org iburst
#server 2.centos.pool.ntp.org iburst
#server 3.centos.pool.ntp.org iburst

# 从server1中同步时间
server 192.168.47.120

# 允许server1修改本地时间
restrict 192.168.47.120 nomodify notrap noquery

# 如果server1不可用，用本地的时间服务
server 127.127.1.0
fudge 127.127.1.0 stratum 10

includefile /etc/ntp/crypto/pw

keys /etc/ntp/keys
disable monitor

# 同步时间后，写到硬件中
SYNC_HWCLOCK=yes
```



#### <2> 每台客户端在启动ntpd服务之前，手动同步一下时间

原因同(5)

```none
[root@server3 ~]# ntpdate ntp.ntsc.ac.cn
```

#### <3> 启动每台客户端的ntpd服务

```none
[root@server3 ~]# systemctl start ntpd
```

#### <4> 等待5-10分钟后，查看每个客户端的状态

```bash
[root@server3 ~]# ntpq -p
```



到这里，利用局域网内一台时间服务器来同步整个集群时间的全部配置就已经完成

### (10) 测试,在几台服务器同时执性date命令

```none
[root@server1 ~]# date '+%Y-%m-%d %H:%M:%S'
2024-02-19 14:27:57
[root@server3 ~]# date '+%Y-%m-%d %H:%M:%S'
2024-02-19 14:27:51
```

说明：若以上提供的网络时间服务器不可用，请自行上网寻找可用的网络时间服务器，另外需要关闭各服务器的防火墙，才能进行时间同步

### 附：常见的时间服务器

|                  名称                   |    公共NTP服务器地址     |
| :-------------------------------------: | :----------------------: |
| 国家授时中心 NTP 服务器 NTSC NTP Server |      ntp.ntsc.ac.cn      |
|    中国 NTP 快速授时服务 NTP ORG CN     |      cn.ntp.org.cn       |
|           上海交大NTP 服务器            |     ntp.sjtu.edu.cn      |
|            清华大学NTP服务器            | ntp.tuna.tsinghua.edu.cn |
|     国际 NTP 快速授时服务 中国片区      |     cn.pool.ntp.org      |