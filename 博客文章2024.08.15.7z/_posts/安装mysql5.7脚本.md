---
title: install_mysql5.7
date: 2024-03-09 09:25:00
updated: 2024-03-09 09:25:00
tags: [Shell脚本]
excerpt: install_mysql5.7 for centos 7/8/stream 8 & ubuntu 18.04/20.04 & Rocky 8
categories: [Shell脚本]
---
## 安装mysql5.7
```bash
#!/bin/bash
#*************************************************************************************************
#FileName:      install_mysql5.7.sh
#Description:   install_mysql5.7 for centos 7/8/stream 8 & ubuntu 18.04/20.04 & Rocky 8
#*************************************************************************************************
SRC_DIR=/opt/src
COLOR="echo -e \\033[01;31m"
END='\033[0m'
MYSQL_URL=https://downloads.mysql.com/archives/get/p/23/file/mysql-5.7.43-linux-glibc2.12-x86_64.tar.gz
MYSQL_VERSION='5.7/'
MYSQL_FILE='mysql-5.7.43-linux-glibc2.12-x86_64.tar.gz'
MYSQL_ROOT_PASSWORD=123456
MYSQL_INSTALL_DIR=/opt/app/mysql-5.7.43  # 修改为你想要的安装目录
mkdir -p /opt/src
mkdir -p /opt/app
os(){
    OS_ID=`sed -rn '/^NAME=/s@.*="([[:alpha:]]+).*"$@\1@p' /etc/os-release`
    OS_RELEASE_VERSION=`sed -rn '/^VERSION_ID=/s@.*="?([0-9]+)\.?.*"?@\1@p' /etc/os-release`
}

check_file(){
    cd  ${SRC_DIR}
    if [ ! -e ${MYSQL_FILE} ];then
        ${COLOR}"缺少${MYSQL_FILE}文件"${END}
        ${COLOR}'开始下载MYSQL二进制安装包'${END}
        wget ${MYSQL_URL} || { ${COLOR}"MYSQL二进制安装包下载失败"${END}; exit; }
    else
        ${COLOR}"${MYSQL_FILE}文件已准备好"${END}
    fi
}

# 检查命令是否存在的函数
command_exists() {
    command -v "$1" &> /dev/null
}

if [[ ${OS_ID} == "CentOS" || ${OS_ID} == "Rocky" ]]; then
    echo "正在检查并安装wget和tar，请稍等！"
    command_exists wget || yum -y install wget &> /dev/null
    command_exists tar || yum -y install tar &> /dev/null
elif [[ ${OS_ID} == "Ubuntu" ]]; then
    echo "正在检查并安装wget和tar，请稍等！"
    command_exists wget || (apt-get update &>/dev/null && apt-get -y install wget &> /dev/null)
    command_exists tar || (apt-get update &>/dev/null && apt-get -y install tar &> /dev/null)
fi

install_mysql(){
    [ -d ${MYSQL_INSTALL_DIR} ] && { ${COLOR}"MySQL数据库已存在，安装失败"${END};exit; }
    ${COLOR}"开始安装MySQL数据库..."${END}
    ${COLOR}'开始安装MYSQL依赖包'${END}
    if [[ ${OS_RELEASE_VERSION} == 8 ]] &> /dev/null;then
        yum -y install libaio perl-Data-Dumper ncurses-compat-libs &> /dev/null
    elif [[ ${OS_RELEASE_VERSION} == 7 ]] &> /dev/null;then
        yum -y install libaio perl-Data-Dumper &> /dev/null
    else
        apt update &> /dev/null;apt -y install numactl libaio-dev libtinfo5 &> /dev/null
    fi
    cd  ${SRC_DIR}
    tar xvf ${MYSQL_FILE}
    mv ${SRC_DIR}/mysql-5.7.43-linux-glibc2.12-x86_64 ${MYSQL_INSTALL_DIR}
    ln -s ${MYSQL_INSTALL_DIR} /usr/local/mysql
    id mysql &> /dev/null || { useradd -s /sbin/nologin -r  mysql ; ${COLOR}"创建mysql用户"${END}; }
    chown -R  mysql.mysql ${MYSQL_INSTALL_DIR}
    echo 'PATH=${MYSQL_INSTALL_DIR}/bin/:$PATH' > /etc/profile.d/mysql.sh
    .  /etc/profile.d/mysql.sh
    cat > /etc/my.cnf <<-EOF
[mysqld]
server-id=1
log-bin
datadir=/data/mysql
socket=/data/mysql/mysql.sock
log-error=/data/mysql/mysql.log
pid-file=/data/mysql/mysql.pid
[client]
socket=/data/mysql/mysql.sock
EOF
    [ -d /data/mysql ] || mkdir -p /data/mysql &> /dev/null
    chown -R  mysql.mysql /data/mysql
    ${MYSQL_INSTALL_DIR}/bin/mysqld --initialize --user=mysql --datadir=/data/mysql 
    cp ${MYSQL_INSTALL_DIR}/support-files/mysql.server  /etc/init.d/mysqld
    if [ ${OS_ID} == "CentOS" -o ${OS_ID} == "Rocky" ] &> /dev/null;then
        chkconfig --add mysqld
    else
        update-rc.d -f mysqld defaults
    fi
    cat > /lib/systemd/system/mysqld.service <<-EOF
[Unit]
Description=mysql database server
After=network.target

[Service]
Type=notify
PrivateNetwork=false
Type=forking
Restart=no
TimeoutSec=5min
IgnoreSIGPIPE=no
KillMode=process
GuessMainPID=no
RemainAfterExit=yes
SuccessExitStatus=5 6
ExecStart=/etc/init.d/mysqld start
ExecStop=/etc/init.d//mysqld stop
ExecReload=/etc/init.d/mysqld reload

[Install]
WantedBy=multi-user.target
Alias=mysqld.service
EOF
    systemctl daemon-reload
    systemctl enable --now mysqld &> /dev/null
    [ $? -ne 0 ] && { ${COLOR}"数据库启动失败，退出!"${END};exit; }
    MYSQL_OLDPASSWORD=`awk '/A temporary password/{print $NF}' /data/mysql/mysql.log`
    ${MYSQL_INSTALL_DIR}/bin/mysqladmin  -uroot -p${MYSQL_OLDPASSWORD} password ${MYSQL_ROOT_PASSWORD} &>/dev/null
    ${COLOR}"MySQL数据库安装完成"${END}
}
ln -s /opt/app/mysql-5.7.43/bin/mysql /usr/local/bin/mysql
main(){
    os
    check_file
    command_exists
    install_mysql
}

main
```