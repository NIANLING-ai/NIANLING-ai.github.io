---
title: install_chrony_client
date: 2024-03-03 09:25:00
updated: 2024-03-03 09:25:00
tags: [Shell脚本]
excerpt: install_chrony_client for CentOS 7/8 & Ubuntu 18.04/20.04 & Rocky 8，理论上其他版本也可安装
categories: [Shell脚本]
---
## 安装chrony客户端
```bash
#!/bin/bash
#
#**********************************************************************************************
#FileName:      install_chrony_client.sh
#Description:   install_chrony_client for CentOS 7/8 & Ubuntu 18.04/20.04 & Rocky 8
#*********************************************************************************************
COLOR="echo -e \\033[01;31m"
END='\033[0m'
SERVERS=("172.31.1.8" "172.31.1.9" "172.31.1.10")  # 这里添加多个服务器地址

os(){
    OS_ID=$(sed -rn '/^NAME=/s@.*="([[:alpha:]]+).*"$@\1@p' /etc/os-release)
}

check_chrony_installed(){
    if [ "${OS_ID}" == "CentOS" ] || [ "${OS_ID}" == "Rocky" ]; then
        rpm -q chrony &> /dev/null && { ${COLOR}"chrony 已经安装"${END}; exit 0; }
    else
        dpkg -l | grep -qw chrony && { ${COLOR}"chrony 已经安装"${END}; exit 0; }
    fi
}

configure_chrony(){
    if [ "${OS_ID}" == "CentOS" ] || [ "${OS_ID}" == "Rocky" ]; then
        CHRONY_CONF="/etc/chrony.conf"
        sed -i -e '/^pool.*/d' -e '/^server.*/d' /etc/chrony.conf
    else
        CHRONY_CONF="/etc/chrony/chrony.conf"
        sed -i -e '/^pool.*/d' /etc/chrony/chrony.conf
    fi

    for SERVER in "${SERVERS[@]}"; do
        echo "server ${SERVER} iburst" >> ${CHRONY_CONF}
    done
}

install_chrony(){
    echo "Installing chrony on ${OS_ID}"
    if [ "${OS_ID}" == "CentOS" ] || [ "${OS_ID}" == "Rocky" ]; then
        yum -y install chrony
        configure_chrony
        systemctl enable --now chronyd
        systemctl is-active chronyd || { ${COLOR}"chrony 启动失败,退出!"${END}; exit 1; }
    else
        apt -y install chrony
        configure_chrony
        systemctl enable --now chronyd
        systemctl is-active chronyd || { ${COLOR}"chrony 启动失败,退出!"${END}; exit 1; }
        systemctl restart chronyd
    fi
    ${COLOR}"chrony 安装完成"${END}
}

show_status(){
    systemctl restart chronyd
    echo "请耐心等待5秒，时间服务器同步中！"
    sleep 5
    echo "当前使用的时间服务器："
    chronyc sources
}

main(){
    os
    check_chrony_installed
    install_chrony
    show_status
}

main
```