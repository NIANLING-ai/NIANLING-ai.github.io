---
title: 监控Mysql脚本
date: 2024-01-15 09:25:00
updated: 2024-01-15 09:25:00
tags: [监控, Mysql, shell]
excerpt: 可以配合Zabbix使用的Mysql监控脚本
categories: [Linux, Mysql]
---

# 监控Mysql脚本

```bash
#!/bin/bash

# 定义MySQL用户名、密码和主机
MYSQL_USER="root"
MYSQL_PASSWORD="123456"
MYSQL_HOST="localhost"

# 检测MySQL服务是否运行
if ! pgrep mysqld >/dev/null 2>&1 ; then
    # 如果MySQL服务未运行，则尝试启动服务
    echo "MySQL is not running, attempting to start..."
    systemctl start mysqld
    sleep 5
    # 再次检查MySQL服务是否已经运行
    if ! pgrep mysqld >/dev/null 2>&1 ; then
        echo "Failed to start MySQL."
        exit 1
    else
        echo "MySQL started successfully."
    fi
fi

# 检查能否连接到MySQL服务器
if ! mysqladmin ping -h "$MYSQL_HOST" -u "$MYSQL_USER" -p"$MYSQL_PASSWORD" >/dev/null 2>&1; then
    echo "Could not connect to MySQL server. Attempting to restart MySQL."
    /etc/init.d/mysql restart
    sleep 5
    if ! mysqladmin ping -h "$MYSQL_HOST" -u "$MYSQL_USER" -p"$MYSQL_PASSWORD" >/dev/null 2>&1; then
        echo "Failed to restart MySQL."
        exit 1
    else
        echo "MySQL restarted successfully."
    fi
else
    echo "MySQL is running."
fi
```
