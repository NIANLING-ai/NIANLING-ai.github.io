---
title: SFTP搭建
date: 2024-01-31 09:25:00
updated: 2024-01-31 09:25:00
tags: [Linux, SFTP]
excerpt: Linux上最简单的SFTP搭建过程
categories: [教程]
---
### SFTP搭建流程
- 准备工作：检查openssh版本
使用系统自带的internal-sftp搭建sftp，因为需要用到chroot，所以openssh 版本不能低于4.8p1
```bash
[root@rocky2 testftp]# ssh -V
OpenSSH_8.0p1, OpenSSL 1.1.1k  FIPS 25 Mar 2021
```
```bash
###第一步：创建用户分组sftp
groupadd sftp

### 第二步：添加用户testftp至分组sftp
useradd -g sftp -s /sbin/nologin zjsftp

### 第三步：修改zjsftp用户的密码
passwd zjsftp
zhangjian@123456

### 第四步：创建一个目录，来专门存放sftp相关文件
mkdir /sftp

### 第五步：在第四步创建的目录下，再创建一个与用户名同名的文件夹
[root@rocky2 ~]# cd /sftp
[root@rocky2 sftp]# mkdir testftp

### 第六步：修改sshd_config的配置文件
vim /etc/ssh/sshd_config
Subsystem       sftp    /usr/libexec/openssh/sftp-server

#在配置文件最后添加
Match Group sftp
ChrootDirectory /sftp/%u
ForceCommand internal-sftp
AllowTcpForwarding no
X11Forwarding no

### 第七步：设定Chroot目录权限
chown root:sftp /sftp
chown root:sftp /sftp/testftp
chmod 755 /sftp
chmod 755 /sftp/testftp

### 第八步：在/sftp/testftp目录下，创建一个文件夹files,并设置该文件夹的拥有者为对应的用户，并设置该文件夹的拥有者有7的权限。这样该用户可以在files目录下进行任何操作(上传、下载、删除、创建等操作)
[root@rocky2 sftp]# cd testftp
[root@rocky2 testftp]# ll
总用量 0
[root@rocky2 testftp]# mkdir files

#设置权限
chown zjsftp /sftp/zjsftp/files
chmod 755 /sftp/zjsftp/files

### 第九步：重启sshd配置
systemctl restart sshd

### 第十步：连接SFTP，验证一下
```


