---
title: install_python3
date: 2024-03-13 09:25:00
updated: 2024-03-13 09:25:00
tags: [Shell脚本]
excerpt: 安装Python3环境，可以与系统中的其他版本共存
categories: [Shell脚本]
---
## 安装Python3环境

- Rocky的环境依赖

```bash
dnf install zlib-devel bzip2 bzip2-devel readline-devel sqlite sqlite-devel openssl-devel tk-devel libffi-devel -y
```

```bash
#!/bin/bash
# 用法: ./install_python.sh <版本号1> [<版本号2> ...],如./install_python.sh 3.7.12 3.8.10 3.9.6

# 安装 wget 和 tar
install_wget_and_tar() {
    echo "Checking for wget and tar..."

    # 判断 wget 和 tar 是否存在
    command -v wget &>/dev/null
    wget_installed=$?
    command -v tar &>/dev/null
    tar_installed=$?

    if [ $wget_installed -eq 0 ] && [ $tar_installed -eq 0 ]; then
        echo "wget and tar are installed."
    else
        echo "Installing wget and tar..."
        if command -v yum &>/dev/null; then
            if [ $wget_installed -ne 0 ]; then
                yum -y install wget
                while [ $? -ne 0 ]; do
                    yum -y install wget
                done
            fi
            if [ $tar_installed -ne 0 ]; then
                yum -y install tar
                while [ $? -ne 0 ]; do
                    yum -y install tar
                done
            fi
        elif command -v apt-get &>/dev/null; then
            apt-get update

            if [ $wget_installed -ne 0 ]; then
                apt-get -y install wget
                while [ $? -ne 0 ]; do
                    apt-get -y install wget
                done
            fi
            
            if [ $tar_installed -ne 0 ]; then
                apt-get -y install tar
                while [ $? -ne 0 ]; do
                    apt-get -y install tar
                done
            fi
        else
            echo "Neither yum nor apt-get is available. Please install wget and tar manually."
            exit 1
        fi
        echo "wget and tar installed successfully."
    fi
}


# 安装指定版本的 Python
install_python() {
  VERSION=$1
  SRC_DIR=/opt/src
  INSTALL_DIR=/opt/app/Python$VERSION

  echo "Checking for Python $VERSION..."
  if command -v python"${VERSION}" >/dev/null 2>&1; then
    echo "Python ${VERSION} is already installed: $(which python${VERSION})"
    return
  fi

  echo "Installing Python ${VERSION}..."
  mkdir -p $SRC_DIR
  cd $SRC_DIR
  echo "Downloading Python ${VERSION}..."
  wget "https://repo.huaweicloud.com/python/$VERSION/Python-$VERSION.tgz" --no-check-certificate -O "Python-$VERSION.tgz"
  if [ $? -ne 0 ]; then
    echo "=========== Download Failed! ============"
    exit 1
  fi

  echo "Extracting Python ${VERSION}..."
  tar -xzvf "Python-$VERSION.tgz"

  echo "Installing Python dependencies..."
  if command -v yum &>/dev/null; then
    yum -y install gcc zlib-devel bzip2-devel ncurses-devel sqlite-devel make readline-devel tk-devel gdbm-devel db4-devel libpcap-devel xz-devel openssl-devel zlib
  elif command -v apt-get &>/dev/null; then
    apt-get update
    apt-get -y install build-essential zlib1g-dev libbz2-dev libncurses5-dev make libncursesw5-dev libreadline-dev libsqlite3-dev tk-dev libgdbm-dev libdb5.3-dev libpcap-dev xz-utils libssl-dev libffi-dev
  fi

  echo "Configuring, compiling and installing Python..."
  cd "Python-$VERSION"
  ./configure --prefix="$INSTALL_DIR" --enable-optimizations
  make -j $(nproc) && make altinstall  #覆盖就用install，共存最好用altinstall
  
  # 自动查找 python3.x 可执行文件
  PYTHON_EXECUTABLE=$(find "$INSTALL_DIR/bin" -name "python3.*" | head -n 1)

  # 创建软链接
  if [[ -n "$PYTHON_EXECUTABLE" ]]; then
    ln -s "$PYTHON_EXECUTABLE" "$INSTALL_DIR/bin/python$VERSION"
  else
    echo "Warning: Could not find python3.x executable in $INSTALL_DIR/bin"
  fi

  ln -s "$INSTALL_DIR/bin/python$VERSION" "/usr/bin/python$VERSION"
  echo "export PATH=\$PATH:$INSTALL_DIR/bin" >> ~/.bashrc

  echo "Python $VERSION installed successfully."
}

# 验证安装
verify_installation() {
  echo "Verifying Python installations..."
  # 加载新的环境变量
  source ~/.bashrc
  while [ $# -gt 0 ]; do
    VERSION=$1
    if command -v python"${VERSION}" >/dev/null 2>&1; then
      echo "Python ${VERSION} installed successfully:"
      python"${VERSION}" --version
    else
      echo "Python ${VERSION} installation failed!"
    fi
    shift
  done
}
# 安装 wget 和 tar
install_wget_and_tar

# 读取传入的版本号参数并安装
while [ $# -gt 0 ]; do
  install_python "$1"
  shift
done

# 验证安装
verify_installation "$@"

echo "Installation complete. Please run 'source ~/.bashrc' to update your environment."
```