---
title: 编译Zabbix6.0.5
date: 2024-01-20 09:25:00
updated: 2024-01-20 09:25:00
tags: [Linux, Zabbix]
excerpt: 编译安装Zabbix6.0.5，实验机器为Rocky,其余机器自行尝试
categories: [Linux, Zabbix]
---

# 编译Zabbix6.0.5

### pgsql数据库配置

环境为Nginx1.24+PHP7.4+PGSQL13.7+Zabbix6.0.5

* 1.安装编译工具和依赖项，有跳过这步骤

```bash
dnf install -y gcc make wget openssl-devel libevent-devel libxml2-devel libcurl-devel libevent-devel pcre-devel libuuid-devel libtool-ltdl-devel postgresql-devel

dnf install php-bcmath -y
dnf install php-sockets -y
```

* 2.下载和解压 Zabbix 源代码

```bash
wget https://cdn.zabbix.com/zabbix/sources/stable/6.0/zabbix-6.0.5.tar.gz
tar -zxvf zabbix-6.0.5.tar.gz && cd zabbix-6.0.5
```

* 3.登录到postgres，创建Zabbix数据库

```bash
CREATE DATABASE zabbix;
CREATE USER zabbix;
ALTER USER zabbix WITH ENCRYPTED PASSWORD '123456';
GRANT ALL PRIVILEGES ON DATABASE zabbix TO zabbix;
```

* 4.给Zabbix配置时序数据库timescaledb

```bash
postgres=# \c zabbix
You are now connected to database "zabbix" as user "postgres".
zabbix=# CREATE EXTENSION IF NOT EXISTS timescaledb CASCADE;
WARNING:
WELCOME TO
 _____ _                               _     ____________
|_   _(_)                             | |    |  _  \ ___ \
  | |  _ _ __ ___   ___  ___  ___ __ _| | ___| | | | |_/ /
  | | | |  _ ` _ \ / _ \/ __|/ __/ _` | |/ _ \ | | | ___ \
  | | | | | | | | |  __/\__ \ (_| (_| | |  __/ |/ /| |_/ /
  |_| |_|_| |_| |_|\___||___/\___\__,_|_|\___|___/ \____/
               Running version 2.11.1
For more information on TimescaleDB, please visit the following links:

 1. Getting started: https://docs.timescale.com/timescaledb/latest/getting-started
 2. API reference documentation: https://docs.timescale.com/api/latest
 3. How TimescaleDB is designed: https://docs.timescale.com/timescaledb/latest/overview/core-concepts

Note: TimescaleDB collects anonymous reports to better understand and assist our users.
For more information and how to disable, please see our docs https://docs.timescale.com/timescaledb/latest/how-to-guides/configuration/telemetry.

CREATE EXTENSION

#查看插件
zabbix=# \dx
                                                List of installed extensions
    Name     | Version |   Schema   |                                      Description
-------------+---------+------------+---------------------------------------------------------------------------------------
 plpgsql     | 1.0     | pg_catalog | PL/pgSQL procedural language
 timescaledb | 2.11.1  | public     | Enables scalable inserts and complex queries for time-series data (Community Edition)
(2 rows)
```

* 5.还是postgres用户状态下，把源码包复制到家目录，导入 Zabbix 数据库模式和数据

```bash
#表在源码包里面，依次导入三个表，不然可能会出错
cd database/postgresql
psql -d zabbix -U zabbix -f schema.sql
psql -d zabbix -U zabbix -f images.sql
psql -d zabbix -U zabbix -f data.sql

#导入时序表，成功会出现下面信息
bash-4.4$ psql -d zabbix -U zabbix -f timescaledb.sql
psql:timescaledb.sql:69: NOTICE:  PostgreSQL version 13.7 is valid
psql:timescaledb.sql:69: NOTICE:  TimescaleDB extension is detected
psql:timescaledb.sql:69: NOTICE:  TimescaleDB version 2.11.1 is valid
psql:timescaledb.sql:69: WARNING:  column type "character varying" used for "source" does not follow best practices
HINT:  Use datatype TEXT instead.
psql:timescaledb.sql:69: WARNING:  column type "character varying" used for "value" does not follow best practices
HINT:  Use datatype TEXT instead.
psql:timescaledb.sql:69: NOTICE:  TimescaleDB is configured successfully
DO
```

### Zabbix安装与配置

* 安装依赖

```bash
dnf --enablerepo=powertools install OpenIPMI-devel -y 
dnf install make wget chrony gcc curl-devel net-snmp-devel libxml2-devel.i686 libevent-devel pcre-devel -y
```

* 创建zabbix用户

```bash
useradd -s /sbin/nologin -M zabbix
```

* .配置编译参数并编译安装，在刚刚解压好的源码包中执行

```bash
./configure -prefix=/usr/local/zabbix --enable-server --enable-agent --with-postgresql --with-openssl --with-libxml2 --with-libcurl --with-uuid --with-libevent

make && make install

chown -R zabbix.zabbix /usr/local/zabbix
```

* 配置Zabbix-server数据库连接

```bash
[root@rocky1 zabbix]# cd /usr/local/zabbix/etc/
[root@rocky1 etc]# vim zabbix_server.conf
DBPassword=123456
DBPort=5432
DBHost=192.168.80.10
LogFile=/var/log/zabbix_server.log  #指定日志位置

#去创建一下这个
touch /var/log/zabbix_server.log  
chown zabbix.zabbix /var/log/zabbix_server.log
```

* 创建Zabbix Server的systemctl 服务管理文件

```bash
vim /usr/lib/systemd/system/zabbix-server.service
[Unit]  
Description=Zabbix Server with PostgreSQL DB  
After=syslog.target network.target postgresql-13.service

[Service]  
Type=simple  
ExecStart=/usr/local/zabbix/sbin/zabbix_server -f  
User=zabbix

[Install]  
WantedBy=multi-user.target

systemctl daemon-reload
```

* 创建Zabbix Agent启动脚本

```bash
vim /lib/systemd/system/zabbix-agent.service
[Unit]
Description=Zabbix Agent
After=syslog.target
After=network.target
[Service]
Environment="CONFFILE=/usr/local/zabbix/etc/zabbix_agentd.conf" EnvironmentFile=-/etc/sysconfig/zabbix-agent
Type=forking
Restart=on-failure
PIDFile=/tmp/zabbix_agentd.pid
KillMode=control-group
ExecStart=/usr/local/zabbix/sbin/zabbix_agentd
ExecStop=/bin/kill -SIGTERM $MAINPID
RestartSec=10s
User=zabbix
Group=zabbix
[Install]
WantedBy=multi-user.target
```

* 使用以下命令启动Zabbix Server及Zabbix Agent

```bash
systemctl enable --now zabbix-server
systemctl enable --now zabbix-agent
```

### 修改 nginx 配置

```bash
#要注意一下，主配置有没有包含到子配置文件，忘了包含踩坑了
vim /apps/nginx/conf.d/zabbix.conf
server {
  listen 80;
  server_name test.zabbix.com;
  location / {
    root /var/www/zabbix;
    index index.php;
  }
  location ~ \.php$ {
    fastcgi_pass 127.0.0.1:9000;
    fastcgi_index index.php;
    fastcgi_param SCRIPT_FILENAME /var/www/zabbix$fastcgi_script_name;
    include fastcgi_params;
  }
}
```

### 修改 php 配置

```bash
vim /apps/php/etc/php-fpm.d/www.conf
user = nginx
group = nginx

vim /apps/php/lib/php.ini
memory_limit = 128M
post_max_size = 16M
upload_max_filesize = 2M
max_execution_time = 300
max_input_time = 300
session.auto_start = 0
mbstring.func_overload = 0
date.timezone = Asia/Shanghai
```

### 创建目录和测试文件

```bash
mkdir -p /var/www/zabbix
chown -R nginx.nginx /var/www/zabbix
vim /var/www/zabbix/index.php
<?php
phpinfo();
?>

#### 启动服务
systemctl enable --now nginx php-fpm


#浏览器访问这个，电脑hosts修改一下,有时候得多等一下或者强制重启nginx，不然好像访问不通
http://test.zabbix.com/index.php
```

### 最终web相关配置

```bash
#把源码包里ui目录下所有文件复制到指定的文件夹里
[root@rocky1 www]# cp -r -a /root/zabbix-6.0.5/ui/* /var/www/zabbix
```

#### 小坑

重启后不知道为啥，Zabbix显示未设置数据库类型  
排查以后发现，zabbix.conf.php文件变成了空白的，从源码里复制一份模板进去根据自己需求修改

```bash
cp /apps/packages/zabbix-6.0.5/ui/conf/zabbix.conf.php.example /var/www/zabbix/conf/zabbix.conf.php

vim /var/www/zabbix/conf/zabbix.conf.php

systemctl restart zabbix-server
```

* 安装中文语言包、检查PHP模块，主要注意一定不能在php.ini中禁用proc\_open函数，否则会导致pdo\_pgsql()函数不可用

```bash
yum reinstall glibc-common -y
yum install langpacks-zh_CN.noarch -y

[root@rocky1 ~]# cd /apps/packages/zabbix-6.0.5/ui/
[root@rocky1 ui]# locale -a
```

![](https://img-130165.oss-cn-shanghai.aliyuncs.com/img/zabbix.png)
