---
title: Windows删除指定日期文件
date: 2024-04-16 09:25:00
updated: 2024-04-16 09:25:00
tags: [WinServer]
excerpt: 删除指定时间以前的文件
categories: [WinServer]
---
## 删除文件
### 按照月份删除
```powershell
# 设置要检查的目录，按照月份删除
$archivePath = "C:\arch"

# 获取当前日期，并减去指定月数，以确定删除的界限
$monthsToSubtract = 6  # 修改为3或其他你需要的月数
$limitDate = (Get-Date).AddMonths(-$monthsToSubtract)

# 获取所有子文件夹
$folders = Get-ChildItem -Path $archivePath -Directory

foreach ($folder in $folders) {
    try {
        # 获取文件夹的最后修改时间
        $folderLastWriteTime = $folder.LastWriteTime

        # 检查文件夹的最后修改时间是否早于限定日期
        if ($folderLastWriteTime -lt $limitDate) {
            # 删除早于指定月数前的文件夹及其内容
            Remove-Item -Path $folder.FullName -Recurse -Force
            Write-Output "已删除: $($folder.FullName)"
        }
    }
    catch {
        Write-Output "删除文件夹时出错: $($folder.Name)"
    }
}
```
### 按照年份删除
```powershell
#按照年删除
# 设置要检查的目录
$archivePath = "C:\arch"

# 获取当前日期，并减去一年，以确定删除的界限
$limitDate = (Get-Date).AddYears(-1)

# 获取所有子文件夹
$folders = Get-ChildItem -Path $archivePath -Directory

foreach ($folder in $folders) {
    try {
        # 获取文件夹的最后修改时间
        $folderLastWriteTime = $folder.LastWriteTime

        # 检查文件夹的最后修改时间是否早于限定日期
        if ($folderLastWriteTime -lt $limitDate) {
            # 删除早于一年前的文件夹及其内容
            Remove-Item -Path $folder.FullName -Recurse -Force
            Write-Output "已删除: $($folder.FullName)"
        }
    }
    catch {
        Write-Output "删除文件夹时出错: $($folder.Name)"
    }
}
```
### 修改文件的修改时间
```powershell
# 指定要检查的根目录
$rootPath = "C:\arch"

# 指定新的修改时间
$newModificationTime = Get-Date "2023-06-25 10:00:00"

# 定义一个递归函数来更新目录和文件的修改时间
function Update-ModificationTime {
    param (
        [string]$path,
        [datetime]$newTime
    )

    try {
        # 修改当前目录的修改时间
        (Get-Item $path).LastWriteTime = $newTime
        Write-Output "目录的修改时间已更新: $path"

        # 修改当前目录下所有文件和子目录的修改时间
        $items = Get-ChildItem -Path $path
        foreach ($item in $items) {
            (Get-Item $item.FullName).LastWriteTime = $newTime

            if ($item.PSIsContainer) {
                # 递归调用函数修改子目录的修改时间
                Update-ModificationTime -path $item.FullName -newTime $newTime
            } else {
                Write-Output "文件的修改时间已更新: $($item.FullName)"
            }
        }
    }
    catch {
        Write-Output "修改 $path 的时间时出错: $_"
    }
}

# 开始更新根目录下的所有目录和文件的修改时间
Update-ModificationTime -path $rootPath -newTime $newModificationTime
```
