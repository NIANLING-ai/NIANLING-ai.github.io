---
title: install_redis
date: 2024-03-25 09:25:00
updated: 2024-03-25 09:25:00
tags: [Shell脚本]
excerpt: install_redis for centos 7/8/stream 8 & ubuntu 18.04/20.04 & Rocky 9
categories: [Shell脚本]
---
## 安装redis
```bash
#!/bin/bash

VERSION=redis-6.2.9
PASSWORD=123456
INSTALL_DIR=/opt/app/redis

color() {
    RES_COL=60
    MOVE_TO_COL="echo -en \\033[${RES_COL}G"
    SETCOLOR_SUCCESS="echo -en \\033[1;32m"
    SETCOLOR_FAILURE="echo -en \\033[1;31m"
    SETCOLOR_WARNING="echo -en \\033[1;33m"
    SETCOLOR_NORMAL="echo -en \E[0m"
    echo -n "$1" && $MOVE_TO_COL
    echo -n "["
    if [ "$2" = "success" -o "$2" = "0" ]; then
        ${SETCOLOR_SUCCESS}
        echo -n $"  OK  "
    elif [ "$2" = "failure" -o "$2" = "1" ]; then
        ${SETCOLOR_FAILURE}
        echo -n $"FAILED"
    else
        ${SETCOLOR_WARNING}
        echo -n $"WARNING"
    fi
    ${SETCOLOR_NORMAL}
    echo -n "]"
    echo
}

install_dependencies() {
    if command -v yum &> /dev/null; then
        yum -y install gcc jemalloc-devel tar wget || { color "安装软件包失败，请检查网络配置" 1; exit; }
    elif command -v apt-get &> /dev/null; then
        apt-get update
        apt-get -y install gcc libjemalloc-dev make wget tar || { color "安装软件包失败，请检查网络配置" 1; exit; }
    else
        color "不支持的系统类型" 1
        exit 1
    fi
}

download_redis() {
    wget http://download.redis.io/releases/${VERSION}.tar.gz || { color "Redis 源码下载失败" 1; exit; }
    tar xf ${VERSION}.tar.gz
    cd ${VERSION}
}

compile_redis() {
    make -j 2 PREFIX=${INSTALL_DIR} install && color "Redis 编译安装完成" 0 || { color "Redis 编译安装失败" 1; exit; }

    ln -s ${INSTALL_DIR}/bin/redis-* /usr/bin/
    mkdir -p ${INSTALL_DIR}/{etc,log,data,run}
    cp redis.conf ${INSTALL_DIR}/etc/

    sed -i -e 's/bind 127.0.0.1/bind 0.0.0.0/' \
           -e "/# requirepass/a requirepass $PASSWORD" \
           -e "/^dir .*/c dir ${INSTALL_DIR}/data/" \
           -e "/logfile .*/c logfile ${INSTALL_DIR}/log/redis-6379.log" \
           -e "/^pidfile .*/c pidfile ${INSTALL_DIR}/run/redis_6379.pid" ${INSTALL_DIR}/etc/redis.conf
}

create_redis_user() {
    if id redis &> /dev/null; then
        color "Redis 用户已存在" 1
    else
        useradd -r -s /sbin/nologin redis
        color "Redis 用户创建成功" 0
    fi
    chown -R redis:redis ${INSTALL_DIR}
}

configure_system() {
    cat >> /etc/sysctl.conf <<EOF
net.core.somaxconn = 1024
vm.overcommit_memory = 1
EOF
    sysctl -p

    if [ -f /etc/rc.d/rc.local ]; then
        echo 'echo never > /sys/kernel/mm/transparent_hugepage/enabled' >> /etc/rc.d/rc.local
        chmod +x /etc/rc.d/rc.local
        /etc/rc.d/rc.local
    elif [ -f /etc/rc.local ]; then
        sed -i -e '$i echo never > /sys/kernel/mm/transparent_hugepage/enabled\n' /etc/rc.local
        chmod +x /etc/rc.local
        /etc/rc.local
    else
        echo '#!/bin/bash' > /etc/rc.local
        echo 'echo never > /sys/kernel/mm/transparent_hugepage/enabled' >> /etc/rc.local
        chmod +x /etc/rc.local
        /etc/rc.local
    fi
}

create_service_file() {
    cat > /etc/systemd/system/redis.service <<EOF
[Unit]
Description=Redis persistent key-value database
After=network.target
 
[Service]
ExecStart=${INSTALL_DIR}/bin/redis-server ${INSTALL_DIR}/etc/redis.conf --supervised systemd
ExecStop=/bin/kill -s QUIT \$MAINPID
#Type=notify
User=redis
Group=redis
RuntimeDirectory=redis
RuntimeDirectoryMode=0755
 
[Install]
WantedBy=multi-user.target
EOF
    systemctl daemon-reload
    systemctl enable --now redis &> /dev/null && color "Redis 服务启动成功, Redis 信息如下:" 0 || { color "Redis 启动失败" 1; exit; }
    sleep 2
    redis-cli -a $PASSWORD INFO Server 2> /dev/null
}

main() {
    install_dependencies
    download_redis
    compile_redis
    create_redis_user
    configure_system
    create_service_file
}

main "$@"
```