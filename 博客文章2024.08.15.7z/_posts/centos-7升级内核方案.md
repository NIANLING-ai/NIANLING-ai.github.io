---
title: CentOS 7升级内核方案
date: 2024-01-23 09:25:00
updated: 2024-01-23 09:25:00
tags: [Linux, 教程]
excerpt: Centos7太老了，有些时候部分业务场景需要更新的内核
categories: [Linux, 教程]
---
## CentOS7升级内核方案

CentOS 7自带的内核版本还停留在`3.x`，如果某些软件对Linux内核版本有要求，就不得不升级内核来支持。

#### 内核版本选择

我们可以从[https://www.kernel.org/](https://cloud.tencent.com/developer/tools/blog-entry?target=https%3A%2F%2Fwww.xgss.net%2Fwp-content%2Fthemes%2Fxgssv1%2Fgo.php%3Furl%3DaHR0cHM6Ly93d3cua2VybmVsLm9yZy8%3D&source=article&objectId=2072001)官网下载指定内核源码并进行编译升级，但是此步骤较为繁琐，不在此次讨论范围。

如果我们采用`rpm`包进行升级，可以使用别人编译好的包，其中`elrepo`提供的内核升级包是比较值得信赖的，内核地址如下：[https://elrepo.org/linux/kernel/el7/x86\_64/RPMS/](https://cloud.tencent.com/developer/tools/blog-entry?target=https%3A%2F%2Fwww.xgss.net%2Fwp-content%2Fthemes%2Fxgssv1%2Fgo.php%3Furl%3DaHR0cHM6Ly9lbHJlcG8ub3JnL2xpbnV4L2tlcm5lbC9lbDcveDg2XzY0L1JQTVMv&source=article&objectId=2072001)

但是打开elrepo的网站我们只能看到`5.15.x`和`5.4.x`（随着时间的推移可能会有变化）两个版本，标识了`ml`和`lt`

<img src="https://img-130165.oss-cn-shanghai.aliyuncs.com/img/be969f09d089a98dbf368791f368f7db.png" style="zoom:80%;" />

* `ml`代表主线版本，总是保持主线最新的内核
* `lt`代表长期支持版本，支持周期更长

再通过[https://www.kernel.org](https://cloud.tencent.com/developer/tools/blog-entry?target=https%3A%2F%2Fwww.xgss.net%2Fwp-content%2Fthemes%2Fxgssv1%2Fgo.php%3Furl%3DaHR0cHM6Ly93d3cua2VybmVsLm9yZy9jYXRlZ29yeS9yZWxlYXNlcy5odG1s&source=article&objectId=2072001)官网对照下上面两个版本的生命周期，可以看到`5.15`支持到2023年，而`5.4`支持到2025年。

![](https://img-130165.oss-cn-shanghai.aliyuncs.com/img/60f7e4a2ad8b6ae79118f8284fa2181f.png)

如果你要追求最新的版本，直接选择带`ml`的rpm包即可，如果你要追求稳定且更长的支持周期，直接选择`lt`版本即可。

#### 在线升级

```bash
#导入ELRepo 公钥
wget https://www.elrepo.org/RPM-GPG-KEY-elrepo.org
rpm --import RPM-GPG-KEY-elrepo.org
#安装ELRepo
rpm -Uvh http://www.elrepo.org/elrepo-release-7.0-3.el7.elrepo.noarch.rpm
#升级最新内核
yum --enablerepo=elrepo-kernel install kernel-ml -y
#升级长期支持的lt内核（二选一即可）
yum --enablerepo=elrepo-kernel install kernel-lt -y
```

#### 离线升级

也可以手动下载`rpm`的内核进行离线升级，以升级`lt`内核为例，方法如下：

```bash
#下载内核(随着时间推移，链接可能失效)
wget https://elrepo.org/linux/kernel/el7/x86_64/RPMS/kernel-lt-5.4.267-1.el7.elrepo.x86_64.rpm
#升级内核
rpm -ivh kernel-lt-5.4.267-1.el7.elrepo.x86_64.rpm
```

#### 切换内核

输入命令`awk -F\' '$1=="menuentry " {print i++ " : " $2}' /boot/grub2/grub.cfg`查看grub2引导序号。

```bash
[root@test ~]# awk -F\' '$1=="menuentry " {print i++ " : " $2}' /boot/grub2/grub.cfg
0 : CentOS Linux (5.4.267-1.el7.elrepo.x86_64) 7 (Core)
1 : CentOS Linux (3.10.0-1160.105.1.el7.x86_64) 7 (Core)
2 : CentOS Linux (3.10.0-1160.el7.x86_64) 7 (Core)
3 : CentOS Linux (0-rescue-6f0ded4d6b374b868728677046097a9c) 7 (Core)
```

可以看到序号`0`是我们刚刚安装的内核，我们将其设置为默认启动内核：

```bash
#设置默认启动内核
grub2-set-default 0
#重启服务器生效
reboot
```

某些服务商可能会遇到设置不生效的问题，我们可采取删除旧内核，保留新内核的做法。需要重启[服务器](https://cloud.tencent.com/act/pro/promotion-cvm?from_column=20065&from=20065)并通过VNC连接（请咨询服务商）并在开机的启动界面选择新内核（5.4）进入，通过以下方法删除旧内核：

```bash
#查看当前内核，确保是以新内核启动
uname -a
#查看系统中全部内核
rpm -qa | grep kernel
#移出不需要的内核
yum remove kernel-3.10.0-229.4.2.el7.x86_64
```

如果系统中只有一个内核，在下次启动的时候就会默认选择该内核启动。

#### 注意

[升级内核](https://cloud.tencent.com/developer/tools/blog-entry?target=https%3A%2F%2Fwww.xgss.net%2Ftag%2F%25e5%258d%2587%25e7%25ba%25a7%25e5%2586%2585%25e6%25a0%25b8&source=article&objectId=2072001)有分险，以上方法不保障升级内核一定成功，生产环境请谨慎操作，如果升级后内核无法启动，可通过VNC连接服务器（咨询服务商），然后选择正常的内核启动，并删除异常的内核进行恢复。

#### 总结

* `ml`代表主线版本，总是保持主线最新的内核
* `lt`代表长期支持版本，支持周期更长
* 内核升级失败，可通过VNC连接选择正常的内核进入系统
* elrepo会经常删除旧的内核，建议定期从elrepo网站将内核下载进行保存，以便后续使用
