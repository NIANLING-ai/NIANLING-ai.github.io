---
title: 安装Tomcat
date: 2024-01-25 09:25:00
updated: 2024-01-25 09:25:00
tags: [Linux, Tomcat]
excerpt: Linux上配置Tomcat服务器
categories: [Linux]
---
## 安装Tomcat

### jdk环境

这里以jdk8环境为例，但是需要账号登陆，wget无法直接使用，需要自行上传安装包到机器中

下载地址：`https://www.oracle.com/java/technologies/downloads/archive/`

- 创建存放目录

```bash
mkdir -p /opt/src
mkdir -p /opt/app/java
```

- 解压压缩包文件到软件目录

```bash
cd /opt/src
tar -zxvf jdk-8u391-linux-x64.tar.gz -C /opt/app/java
```

- 查看一下是否解压成功

```bash
[root@server1 ~]# ls /opt/app/java
jdk1.8.0_391
```

- 添加环境变量

```bash
[root@server1 ~]# vim /etc/profile
export JAVA_HOME=/opt/app/java/jdk1.8.0_391
export JRE_HOME=${JAVA_HOME}/jre
export CLASSPATH=.:${JAVA_HOME}/lib:${JRE_HOME}/lib
export PATH=$PATH:$JAVA_HOME/bin

[root@server1 ~]# source /etc/profile
```

- 验证一下版本信息

```bash
[root@server1 ~]# java -version
java version "1.8.0_391"
Java(TM) SE Runtime Environment (build 1.8.0_391-b13)
Java HotSpot(TM) 64-Bit Server VM (build 25.391-b13, mixed mode)
```

### tomcat的安装

- 下载解压tomcat

```bash
cd /opt/app
wget https://dlcdn.apache.org/tomcat/tomcat-9/v9.0.86/bin/apache-tomcat-9.0.86.tar.gz
tar -zxvf apache-tomcat-9.0.86.tar.gz
```

- 进入bin目录下

```bash
cd /opt/app/apache-tomcat-9.0.86/bin
```

- 启动

```bash
./startup.sh
#输出如下：
Using CATALINA_BASE:   /opt/app/apache-tomcat-9.0.86
Using CATALINA_HOME:   /opt/app/apache-tomcat-9.0.86
Using CATALINA_TMPDIR: /opt/app/apache-tomcat-9.0.86/temp
Using JRE_HOME:        /opt/app/java/jdk1.8.0_391
Using CLASSPATH:       /opt/app/apache-tomcat-9.0.86/bin/bootstrap.jar:/opt/app/apache-tomcat-9.0.86/bin/tomcat-juli.jar
Using CATALINA_OPTS:
Tomcat started.
```

- 查看tomcat进程

```bash
[root@server1 ~]# ps aux |grep tomcat
root       4285  0.4 12.1 2999672 226480 pts/0  Sl   21:06   0:11 /opt/app/java/jdk1.8.0_391/bin/java -Djava.util.logging.config.file=/root/apache-tomcat-9.0.86/conf/logging.properties -Djava.util.logging.manager=org.apache.juli.ClassLoaderLogManager -Djdk.tls.ephemeralDHKeySize=2048 -Djava.protocol.handler.pkgs=org.apache.catalina.webresources -Dorg.apache.catalina.security.SecurityListener.UMASK=0027 -Dignore.endorsed.dirs= -classpath /root/apache-tomcat-9.0.86/bin/bootstrap.jar:/root/apache-tomcat-9.0.86/bin/tomcat-juli.jar -Dcatalina.base=/root/apache-tomcat-9.0.86 -Dcatalina.home=/root/apache-tomcat-9.0.86 -Djava.io.tmpdir=/root/apache-tomcat-9.0.86/temp org.apache.catalina.startup.Bootstrap start
root       4396  0.0  0.0 112812   976 pts/0    S+   21:48   0:00 grep --color=auto tomcat
```

- 访问

```bash
通过 ip:8080访问网页
```

### tomcat配置

Tomcat的主要目录结构大致如下：

1. `bin/`：此目录包含了用于启动和停止Tomcat的脚本。例如，`startup.sh`用于在Unix/Linux系统上启动Tomcat，而`shutdown.sh`则用于停止Tomcat。
2. `conf/`：此目录包含了Tomcat的配置文件，如`server.xml`，在这些文件中可以对Tomcat的行为做出具体的配置。
3. `lib/`：此目录存储了Tomcat运行所需的Java库文件。
4. `logs/`：此目录包含了Tomcat运行时产生的日志文件。
5. `temp/`：此目录用于存储Tomcat运行时产生的临时文件。
6. `webapps/`：这是Tomcat默认的应用部署目录，把你的应用（一般是WAR文件）放在这里，Tomcat就会自动部署并启动这个应用。
7. `work/`：这个目录用于存储Tomcat的工作文件，比如JSP文件编译后产生的Servlet等。
8. `LICENSE`, `RUNNING.txt`, `README.md`等：这些文件包含了关于Tomcat的版权、运行指南、读我等信息。

#### 修改端口号

```bash
vim /opt/app/apache-tomcat-9.0.86/conf/server.xml
#修改如下段，修改成没被占用的端口：
  <Connector port="8088" protocol="HTTP/1.1"
               connectionTimeout="20000"
               redirectPort="8443"
               maxParameterCount="1000"
               />
               
#修改完重启tomcat
cd /opt/app/apache-tomcat-9.0.86/bin
./shutdown.sh
./startup.sh
```

