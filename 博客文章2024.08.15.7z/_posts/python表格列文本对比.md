---
title: Python对表格列文本比对
date: 2024-04-05 09:25:00
updated: 2024-05-27 09:25:00
tags: [Python脚本]
excerpt: 用来比对表格文件列文本并调整顺序的Python脚本
categories: [Python脚本]
---
## Python对表格列文本比对

### 对比前两列

- 并重新排序第二列的顺序与第一列相同

```python
import pandas as pd
#表格文件格式为第一列数据多，第二列数据少为宜，最后看1、4两列就行
# 读取表格数据
df = pd.read_excel('feixing.xlsx')

# 假设第一行就是列名，提取第一和第四列的列名
first_column_name = df.columns[0]
second_column_name = df.columns[1]

# 提取第一列和第二列数据
first_column = df[first_column_name]
second_column = df[second_column_name].tolist()  # 将Pandas序列转为Python的列表

# 初始化空的新列（相当于第三列）和调整后的第二列
duplicates = []
adjusted_second_column = []

for value in first_column:
    if value in second_column:
        # 找到第二列中相同值的索引，并添加到调整后的第二列
        index = second_column.index(value)
        adjusted_second_column.append(second_column[index])
        del second_column[index]  # 删除该元素防止重复计算
        duplicates.append(value)
    else:
        duplicates.append("")
        adjusted_second_column.append("")

# 将剩下的second_column的元素添加到adjusted_second_column列表的末尾
adjusted_second_column += second_column

# 将重复的资产编号（相当于新的第三列）写入DataFrame
df['重复值'] = duplicates

# 创建一个新的Series来存储调整后的第二列数据
adjusted_second_series = pd.Series(adjusted_second_column)

# 将调整后的第二列添加到DataFrame中，列名为“mod_”与原第二列名字的格式
df['mod_' + second_column_name] = adjusted_second_series

# 保存修改后的表格
df.to_excel('修改后的表格文件.xlsx', index=False)
```

### 多列信息对比填充

```python
import pandas as pd

# 读取表格数据，一般第一列是需要填充的信息，二三四列是一一对应的信息，最后看五六列，列数可以自行调整
df = pd.read_excel('1.xlsx')

# 自动获取前四列的列名
col_1, col_2, col_3, col_4 = df.columns[:4]

# 创建一个字典，将第二列的标识符作为键，第三和第四列的组合作为值
identifier_to_info = {k: (v1, v2) for k, v1, v2 in zip(df[col_2], df[col_3], df[col_4])}

# 初始化用于存放匹配到的第三和第四列信息的列表
info_column = []

for value in df[col_1]:
    # 在字典中查找对应的第三和第四列信息
    if value in identifier_to_info:
        # 如果找到了匹配，将信息添加到列表中
        info_column.append(identifier_to_info[value])
    else:
        # 如果没有找到匹配，添加空信息
        info_column.append(("", ""))

# 根据提供的信息自动给第五列和第六列生成列名（示例）
new_col_5_name = '{}的信息'.format(col_3) # 例如："第三列的信息"
new_col_6_name = '{}的细节'.format(col_4) # 例如："第四列的细节"

# 将列表转换为DataFrame的两列，并使用生成的列名
df[new_col_5_name], df[new_col_6_name] = zip(*info_column)

# 保存修改后的表格
df.to_excel('修改后的表格文件.xlsx', index=False)
```

### 输出两列的差异数据

#### 存在于第二列但不在第一列

```python
import pandas as pd

# 读取Excel文件
df = pd.read_excel('2.xlsx', engine='openpyxl')  # 假设输入文件名为input.xlsx

# 将第一列和第二列的值分别转为集合
set_column1 = set(df['Column1'].dropna())
set_column2 = set(df['Column2'].dropna())

# 计算第二列独有的元素
unique_to_column2 = list(set_column2 - set_column1)

# 创建一个空列表来存储输出结果
difference = [None] * len(df)

# 填充存在于第二列但不在第一列的值到difference列表中
for i, item in enumerate(df['Column2']):
    if item in unique_to_column2:
        difference[i] = item

# 将difference列表添加为新列到DataFrame中
df['Difference'] = difference

# 将修改后的DataFrame写入新的Excel文件
df.to_excel('output.xlsx', index=False, engine='openpyxl')
```

#### 存在于第一列但不在第二列

```python
import pandas as pd

# 读取Excel文件
df = pd.read_excel('2.xlsx', engine='openpyxl')  # 假设输入文件名为input.xlsx

# 将第一列和第二列的值分别转为集合
set_column1 = set(df['Column1'].dropna())
set_column2 = set(df['Column2'].dropna())

# 计算第一列独有的元素
unique_to_column1 = list(set_column1 - set_column2)

# 创建一个空列表来存储输出结果
difference = [None] * len(df)

# 填充存在于第一列但不在第二列的值到difference列表中
for i, item in enumerate(df['Column1']):
    if item in unique_to_column1:
        difference[i] = item

# 将difference列表添加为新列到DataFrame中
df['Difference'] = difference

# 将修改后的DataFrame写入新的Excel文件
df.to_excel('output.xlsx', index=False, engine='openpyxl')
```

