---
title: push_ssh_key
date: 2024-03-20 09:25:00
updated: 2024-03-20 09:25:00
tags: [Shell脚本]
excerpt: push ssh_key for CentOS 7/8 & Ubuntu 18.04/24.04 & Rocky 9
categories: [Shell脚本]
---
## 机器互信配置（同网段的机器密钥拷贝）
```bash
#!/bin/bash
#
#**********************************************************************************************
# Description:   ssh_key for CentOS 7/8 & Ubuntu 18.04/24.04 & Rocky 9
#**********************************************************************************************
# 基于key验证多主机ssh互相访问
COLOR="echo -e \\033[01;31m"
END='\033[0m'
PASS=1
# 设置网段最后的地址，4-255之间，越小扫描越快
END=254

# 自动获取当前机器的网卡名称
NIC=$(ip -o -4 a s | awk '!/ lo| docker0/ {split($2, arr, "\n"); print arr[1]}' | head -n1)
IP=$(ip -o -4 a s $NIC | awk '{print $4}' | cut -d/ -f1)
NET=${IP%.*}.

FAILED_IPS=()
ALIVE_IPS=()

os() {
    OS_ID=$(sed -rn '/^NAME=/s@.*="([[:alpha:]]+).*"$@\1@p' /etc/os-release)
}

check_ping() {
    if ! command -v ping &>/dev/null; then
        if [ "${OS_ID}" == "CentOS" ] || [ "${OS_ID}" == "Rocky" ]; then
            ${COLOR}"安装ping包"${END}; yum -y install iputils &>/dev/null
        else
            ${COLOR}"安装ping包"${END}; apt -y install iputils-ping &>/dev/null
        fi
    fi
}

ssh_key_push() {
    rm -f /root/.ssh/id_rsa
    [ -e ./SCANIP.log ] && rm -f SCANIP.log
    touch SCANIP.log # 确保文件存在
    
    echo "Starting to ping IPs..."
    for ((i = 3; i <= END; i++)); do
        ping -c 1 -w 1 ${NET}${i} &>/dev/null && echo "${NET}${i}" >>SCANIP.log &
    done
    wait # 确保所有 ping 命令完成后再继续

    echo "Ping scan completed. Here are the alive IPs:"
    cat SCANIP.log

    # 确保 .ssh 目录存在
    mkdir -p /root/.ssh

    ssh-keygen -f /root/.ssh/id_rsa -P '' &>/dev/null
    if [ "${OS_ID}" == "CentOS" ] || [ "${OS_ID}" == "Rocky" ]; then
        rpm -q sshpass &>/dev/null || { ${COLOR}"安装sshpass软件包"${END}; yum -y install sshpass &>/dev/null; }
    else
        dpkg -S sshpass &>/dev/null || { ${COLOR}"安装sshpass软件包"${END}; apt -y install sshpass &>/dev/null; }
    fi

    ALIVE_IPS=($(cat SCANIP.log)) # 读取刚刚创建的 SCANIP.log 文件
    for n in "${ALIVE_IPS[@]}"; do
        if sshpass -p $PASS ssh-copy-id -o StrictHostKeyChecking=no root@${n} &>/dev/null; then
            echo "Successfully copied SSH key to ${n}"
        else
            ${COLOR}"Permission denied for ${n}, skipping."${END}
            FAILED_IPS+=($n)
            continue
        fi
    done

    # 把.ssh/known_hosts拷贝到所有主机，使它们第一次互相访问时不需要输入回车
    for n in "${ALIVE_IPS[@]}"; do
        if [[ ! " ${FAILED_IPS[@]} " =~ " ${n} " ]]; then
            if scp -o StrictHostKeyChecking=no /root/.ssh/known_hosts root@${n}:.ssh/ &>/dev/null; then
                echo "Successfully copied known_hosts to ${n}"
            else
                ${COLOR}"Permission denied for ${n}, skipping."${END}
                FAILED_IPS+=($n)
                continue
            fi
        fi
    done

    if [ ${#FAILED_IPS[@]} -ne 0 ]; then
        ${COLOR}"以下机器因Permission denied而跳过:"${END}
        for ip in "${FAILED_IPS[@]}"; do
            echo $ip
        done
    fi
}

main() {
    os
    check_ping
    ssh_key_push
}

main
```