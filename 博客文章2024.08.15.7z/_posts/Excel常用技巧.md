---
title: Excel常用的技巧
date: 2024-06-15 09:25:00
updated: 2024-06-15 09:25:00
tags: [Excel]
excerpt: 一些常用的Excel表格操作技巧
categories: [Excel]
---

### 消除表格中的数字

```vbscript
=SUBSTITUTE(SUBSTITUTE(SUBSTITUTE(SUBSTITUTE(SUBSTITUTE(SUBSTITUTE(SUBSTITUTE(SUBSTITUTE(SUBSTITUTE(SUBSTITUTE(B1:B50, "0", ""), "1", ""), "2", ""), "3", ""), "4", ""), "5", ""), "6", ""), "7", ""), "8", ""), "9", "")
```

### 快速删除空白行

- **使用查找和定位功能**： 

- 按`Ctrl+G`打开“定位”对话框，点击“定位条件”，然后选择“空值”，这样所有的空白行就会被选中。接着，右键点击选中的空白行，选择“删除”，然后选择“整行”来删除这些行。