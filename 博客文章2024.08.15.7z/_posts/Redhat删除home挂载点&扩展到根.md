---
title: Redhat删除/home挂载点&扩展到根
date: 2024-05-30 09:25:00
updated: 2024-05-30 09:25:00
tags: [Linux]
excerpt: 删除已有分区，扩展到根目录
categories: [Linux]
---
## Redhat删除/home挂载点&扩展到根

- 备份/home目录的数据（看情况）

```bash
sudo tar -czvf /root/home_backup.tar.gz /home
```

- 卸载/home挂载点

```bash
sudo lsof +D /home
找到进程ID（PID），然后终止这些进程。例如，假设你找到的某个进程ID是1234：
sudo kill -9 1234
umount /home
```

- 禁用并移除逻辑卷

```bash
sudo lvremove /dev/rhel/home
#系统会提示你确认删除，输入y并按Enter
```

- 扩展根目录

```bash
#扩展根逻辑卷rhel-root，将之前/home逻辑卷的空间分配给根逻辑卷。首先，分配rhel-home空间到rhel-root，你可以查看VG（Volume Group）信息以确定可用空间（这里假设VG名字是rhel）：
sudo vgdisplay
sudo lvextend -l +100%FREE /dev/rhel/root
```

- 调整文件系统大小

```bash
sudo xfs_growfs /dev/rhel/root
#也可以确定一下使用的文件系统再操作：df -Th | grep '/dev/rhel/root'
```

- 创建新的/home目录

```bash
mkdir -p /home
```

- 恢复/home数据（看情况）

```bash
sudo tar -xzvf /root/home_backup.tar.gz -C /
sudo reboot #可以不重启
```

