---
title: Clash配置负载
date: 2024-01-16 09:25:00
updated: 2024-01-16 09:25:00
tags: [Clash,小教程]
excerpt: Clash设置负载的脚本，可以让节点满速下载
categories: [教程]
---

# Clash配置负载

## 实现负载，下载拉满带宽

* 找到settings—–>Profiles——->Parsers——>Edit，然后添加下面代码

![](https://img-130165.oss-cn-shanghai.aliyuncs.com/img/clash.png)

```none
parsers:
  - reg: 'slbable$'
    yaml:
      append-proxy-groups:
        - name:  负载均衡-散列
          type: load-balance
          url: 'http://www.google.com/generate_204'
          interval: 300
          strategy: consistent-hashing
        - name:  负载均衡-轮询
          type: load-balance
          url: 'http://www.google.com/generate_204'
          interval: 300
          strategy: round-robin
      commands:
        - proxy-groups. 负载均衡-散列.proxies=[]proxyNames
        - proxy-groups.0.proxies.0+ 负载均衡-散列
        - proxy-groups. 负载均衡-轮询.proxies=[]proxyNames
        - proxy-groups.0.proxies.0+ 负载均衡-轮询
```

* 然后在订阅链接后面添加触发条件，点击更新
* 会出现一个轮询，一个散列，下载建议用轮询，正常用就用散列

