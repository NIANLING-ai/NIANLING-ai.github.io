---
title: 用Shell脚本给Linux添加回收站并实现自动维护
date: 2024-07-28 09:25:00
updated: 2024-07-28 09:25:00
tags: [Linux]
excerpt: 用Shell脚本给Linux添加回收站并实现自动维护
categories: [Linux]
---

# 用Shell脚本给Linux添加回收站并实现自动维护

在`Linux`系统中，删除文件通常是通过`rm`命令直接移除文件，这意味着文件一旦被删除，就很难恢复。因此，许多用户在日常操作中可能需要一个类似于`Windows`系统的回收站功能。本文将介绍如何使用`Shell`脚本为`Linux`系统增加回收站功能，并实现定期自动清理回收站的内容。

## 回收站功能的基本原理

在`Linux`下模拟回收站功能的思路是：将用户删除的文件或目录移动到一个特定的目录（例如`~/.trash`），而不是直接删除。这样，用户可以在需要时从回收站中恢复文件。此外，为了防止回收站无限制地占用磁盘空间，脚本还需要支持定期清理回收站中过期的文件。

## 创建回收站目录

首先，我们需要为回收站创建一个目录。可以在用户的主目录下创建一个名为`.trash`的隐藏目录：

```bash
mkdir -p ~/.trash
```

## 实现`trash`命令

接下来，我们编写一个名为`trash`的Shell脚本，用于替代`rm`命令来执行文件的“删除”操作。该脚本将文件移动到回收站目录中，并记录下文件的原始路径以便将来恢复。

```bash
#!/bin/bash

# 回收站目录
TRASH_DIR="$HOME/.trash"

# 确保回收站目录存在
if [ ! -d "$TRASH_DIR" ]; then
    mkdir -p "$TRASH_DIR"
fi

# 判断是否提供了文件名参数
if [ $# -eq 0 ]; then
    echo"Usage: $0 file_or_directory"
    exit 1
fi

# 遍历所有传递的参数
for FILE in"$@"; do
    if [ -e "$FILE" ]; then
        # 获取当前日期时间，用于重命名文件防止冲突
        TIMESTAMP=$(date +%Y%m%d%H%M%S)
        BASENAME=$(basename "$FILE")
        NEW_NAME="$BASENAME-$TIMESTAMP"
        mv "$FILE""$TRASH_DIR/$NEW_NAME"
        echo"Moved '$FILE' to '$TRASH_DIR/$NEW_NAME'"
    else
        echo"'$FILE' does not exist!"
    fi
done
```

将该脚本保存为`~/bin/trash`，并赋予其可执行权限：

```bash
chmod +x /bin/trash.sh
```

现在把`trash`这边命令通过别名的方式替换原系统的`rm`命令，编辑`/etc/profile`，在文件开头添加如下内容：

```bash
alias rm=/bin/trash.sh
```

现在，用户可以使用rm命令来“删除”文件，例如：

```bash
rm myfile.txt
```

此操作将文件`myfile.txt`移动到`~/.trash`目录，并在文件名后附加一个时间戳以避免重名。

## 实现自动清理回收站

为了避免回收站无限制地占用磁盘空间，我们可以编写一个脚本来定期清理回收站中的旧文件。例如，可以删除超过30天的文件。

```bash
#!/bin/bash

# 回收站目录
TRASH_DIR="$HOME/.trash"

# 删除30天前的文件
find "$TRASH_DIR" -type f -mtime +30 -exec rm -f {} \;

echo"Trash cleaned up."
```

将该脚本保存为`/bin/clean_trash.sh`，并赋予其可执行权限：

```bash
chmod +x /bin/clean_trash.sh
```

为了让清理任务自动执行，可以将该脚本添加到crontab中，例如每天运行一次：

```bash
(crontab -l ; echo "0 2 * * * /bin/clean_trash.sh") | crontab -
```

这条crontab指令表示每天凌晨2点运行`clean_trash`脚本，自动清理回收站。

## 总结

通过上述步骤，我们已经成功地在Linux系统中实现了一个简单的回收站功能，并且可以自动清理回收站中过期的文件。这不仅保护了用户在误删文件时的恢复能力，还帮助用户有效管理磁盘空间。此解决方案可根据实际需求进行进一步的扩展和优化，例如增加文件恢复功能、通过参数调整保留时间等。