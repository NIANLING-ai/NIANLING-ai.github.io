---
title: Linux批量创建用户脚本
date: 2024-03-03 09:25:00
updated: 2024-03-03 09:25:00
tags: [Shell脚本]
excerpt: 可以批量创建用户，并且指定密码，属组等信息
categories: [Shell脚本]
---
## Linux批量创建用户脚本

- `userlist.txt`文件遵循`用户名:密码:是否创建家目录(Y/N):是否允许登录(Y/N):组名`的格式

```bash
johndoe:password123:Y:Y:IT,marketing
```

> tips:是否允许登录(Y/N)这一条不写东西，默认就是允许用户登录

```bash
#!/bin/bash

# 用户名单文件位置
USERLIST=/root/userlist.txt

# 检查并确保用户列表文件存在
if [ ! -f "$USERLIST" ]; then
    echo "用户列表文件不存在: $USERLIST"
    exit 1
fi

# 创建组的函数，如果组不存在则创建它
ensure_group_exists() {
    local group_name=$1
    if ! getent group "$group_name" > /dev/null; then
        echo "组 $group_name 不存在，正在创建..."
        groupadd "$group_name"
        if [ $? -ne 0 ]; then
            echo "无法创建组: $group_name" >&2
            exit 1
        fi
    fi
}

# 逐行读取 userlist.txt 文件内容并创建用户
while IFS=: read -r username password create_home allow_login groups; do
    # 检查是否创建家目录
    home_option=""
    if [ "$create_home" = "Y" ]; then
        home_option="-m"
    fi

    # 根据是否允许登录设置shell
    shell_option="/bin/bash"
    if [ "$allow_login" = "N" ]; then
        shell_option="/usr/sbin/nologin"
    fi

    # 分割组名，确保每个组都存在
    IFS=',' read -ra GROUP_ARRAY <<< "$groups"
    for group in "${GROUP_ARRAY[@]}"; do
        ensure_group_exists "$group"
    done

    # 将分割后的组名数组转换为逗号分隔的字符串
    groups_option=$(IFS=,; echo "${GROUP_ARRAY[*]}")

    # 创建用户，并且将用户添加到指定的多个组
    echo "正在添加用户 $username..."
    if [ -z "$groups_option" ]; then
        useradd $home_option -s $shell_option "$username"
    else
        useradd $home_option -s $shell_option -G "$groups_option" "$username"
    fi
    
    if [ $? -ne 0 ]; then
        echo "添加用户 $username 失败" >&2
        continue
    fi

    # 设置用户密码
    echo "$username:$password" | chpasswd
    if [ $? -ne 0 ]; then
        echo "为用户 $username 设置密码失败" >&2
    else
        echo "用户 $username 添加成功。"
    fi
done < "$USERLIST"

echo "用户创建过程完成。"
```

- 赋予权限并执行

```bash
chmod +x /path/to/your/script.sh
bash /path/to/your/script.sh
```
### 指定主组

- 确保将第一组名作为主组，并确保其余组名作为附加组。这样就可以准确地控制用户属于的主组和附加组。

```bash
#!/bin/bash

USERLIST=/root/userlist.txt

if [ ! -f "$USERLIST" ]; then
    echo "用户列表文件不存在: $USERLIST"
    exit 1
fi

ensure_group_exists() {
    local group_name=$1
    if ! getent group "$group_name" > /dev/null; then
        echo "组 $group_name 不存在，正在创建..."
        groupadd "$group_name"
        if [ $? -ne 0 ]; then
            echo "无法创建组: $group_name" >&2
            exit 1
        fi
    fi
}

while IFS=: read -r username password create_home allow_login groups; do
    home_option=""
    if [ "$create_home" = "Y" ]; then
        home_option="-m"
    fi

    shell_option="/bin/bash"
    if [ "$allow_login" = "N" ]; then
        shell_option="/usr/sbin/nologin"
    fi

    IFS=',' read -ra GROUP_ARRAY <<< "$groups"
    main_group=${GROUP_ARRAY[0]}
    for group in "${GROUP_ARRAY[@]}"; do
        ensure_group_exists "$group"
    done

    groups_option=$(IFS=,; echo "${GROUP_ARRAY[*]}")

    echo "正在添加用户 $username..."
    if [ -z "$groups_option" ]; then
        useradd $home_option -s $shell_option "$username"
    else
        useradd $home_option -s $shell_option -g "$main_group" -G "$groups_option" "$username"
    fi
    
    if [ $? -ne 0 ]; then
        echo "添加用户 $username 失败" >&2
        continue
    fi

    echo "$username:$password" | chpasswd
    if [ $? -ne 0 ]; then
        echo "为用户 $username 设置密码失败" >&2
    else
        echo "用户 $username 添加成功。"
    fi
done < "$USERLIST"

echo "用户创建过程完成。"
```



