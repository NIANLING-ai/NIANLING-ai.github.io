---
title: iptables常用命令
date: 2024-03-25 09:25:00
updated: 2024-03-25 09:25:00
tags: [Linux]
excerpt: iptables常用命令
categories: [Linux]
---
# iptables常用命令

### iptables简介

`iptables` 是一个在 `Linux` 操作系统上用于配置 `IPv4` 数据包过滤规则的工具。它允许系统管理员控制数据包如何流经网络接口，可以用于设置防火墙规则、网络地址转换（`NAT`）以及数据包审计等功能。通过配置 `iptables`，管理员可以定义允许或拒绝特定类型的流量通过服务器，从而增强网络安全性，并实现网络流量的控制和管理。iptables 非常灵活，可以根据网络包的源地址、目标地址、端口号等多种条件进行过滤和转发

- iptables语法构成:

```bash
iptables -t 表名  链名 条件  -j  控制类型
#不指定表名时，默认指filter表
#不指定链名时，默认指表内的所有链
#除非设置链的默认策略，否则必须指定匹配条件#选项、链名、控制类型使用大写字母，其余均为小写字母
```

- 常见动作类型：

```bash
ACCEPT:允许通过
DROP:直接丢弃，不给出任何回应
REJECT:拒绝通过，必要时会给出提示
LOG:记录日志信息，然后传给下一条规则继续匹配
SNAT:修改数据包源地址
DNAT：修改数据包目的地址
EDIRECT:重定向
```

- 常见通用匹配条件：

```bash
协议匹配：-p  协议名
地址匹配：-s 源地址、-d目的地址
接口匹配：-i 入站网卡、-o出站网卡
```

### 实用例子

1）查询当前规则

```bash
iptables -nvL
```

<img src="https://img-130165.oss-cn-shanghai.aliyuncs.com/img/20240730153900.png" style="zoom:67%;" />

2）创建自定义链路表

```bash
iptables -N my-rule

#再用iptables -nvL查一下，就出现了
```

![image-20240730154249164](https://img-130165.oss-cn-shanghai.aliyuncs.com/img/image-20240730154249164.png)

3）在添加的自定义链路中写入规则

```bash
#允许源地址为192.168.10.6的用户访问我的22端口
iptables -A my-rule -s 192.168.10.6 -p tcp --dport 22 -j ACCEPT

#拒绝访问22端口
iptables -A my-rule  -p tcp --dport 22 -j DROP

#在入口流量方向调用自定义防火墙链路表
iptables -A INPUT -j my-rule
```


> 在另一台主机远程连接测试效果,只允许192.168.10.6进行访问，其他客户端向22端口发起的连接都会被拒绝掉

```bash
[root@test2 ~]# ssh root@192.168.10.39
ssh: connect to host 192.168.10.39 port 22: Connection timed out
```


4）删除规则

```bash
iptables -nvL --line-number
#删除my-rule表中序号为2的规则iptables -D my-rule 2
```

5）丢弃请求与拒绝请求

```bash
#当用户访问80端口时直接将请求丢弃
iptables -A INPUT -p tcp --dport 80 -j DROP
```

由于是直接把请求丢弃，直到超时才会回显失败信息


配置规则为拒绝

```bash
iptables -A INPUT -p tcp --dport 80 -j REJECT
```

此时在客户端进行访问时会立即得到拒绝连接的回显

6）允许主机通过icmp协议访问其他设备，但是其他设备不能通过icmp访问我

```bash
iptables -A INPUT -p icmp --icmp-type 0 -j ACCEPT
iptables -A INPUT -p icmp --icmp-type 3 -j ACCEPT
iptables -A INPUT -p icmp -j DROP

#常见ICMP消息类型
Echo Request (Type 8)：用于发送请求并等待 Echo Reply 响应。
Echo Reply (Type 0)：对 Echo Request 进行回应。
Destination Unreachable (Type 3)：目的地不可达的报文类型，包括以下子类型：
Network Unreachable (Code 0)：目标网络不可达。
Host Unreachable (Code 1)：目标主机不可达。
Protocol Unreachable (Code 2)：目标协议不可达。
Port Unreachable (Code 3)：目标端口不可达。
Fragmentation Needed and Don't Fragment was Set (Code 4)：需要进行分片但不允许分片。
Source Route Failed (Code 5)：源路由失败。
Redirect (Type 5)：重定向报文类型，用于告诉发送方其路由表中的一个更佳路径。
Time Exceeded (Type 11)：超时报文类型，包括以下子类型：
Time to Live Exceeded in Transit (Code 0)：传输过程中的 TTL（Time to Live）超时。
Fragment Reassembly Time Exceeded (Code 1)：分片重组超时。
Parameter Problem (Type 12)：参数问题报文类型，用于指示 IP 报文头部的问题。
```

7）批量放行或拒绝多个端口

```bash
#-m multiport 表示启用多端口匹配模块，以便可以匹配多个目的端口
iptables -A INPUT -p tcp -m multiport --dport 20,21,80 -j DROP
```

8）批量放行或拒绝一个连续的IP

```bash
#-m iprange 表示使用 iprange 模块进行 IP 范围匹配。
iptables -I INPUT -m iprange --src-range 192.168.10.1-192.168.10.100 -j ACCEPT
```

9）针对mac地址做限制

```bash
#-m mac 表示使用 mac 模块进行 MAC 地址匹配
iptables -I INPUT -m mac --mac-source 00:0c:29:ac:77:f5 -j DROP
```

10）连接状态匹配

```bash
NEW：新建连接。
ESTABLISHED：已建立连接。
RELATED：与已建立连接相关的数据包，如 FTP 数据传输过程中的控制连接和数据连接。
INVALID：无效的数据包，无法被识别为任何已知连接状态的数据包。
UNTRACKED：未被追踪的数据包。
```

> 放行已建立的连接，丢弃新连接

```bash
#-I 从最上方插入规则，-A 从最下方插入规则
iptables -I INPUT -p tcp -m state --state ESTABLISHED -j ACCEPT
iptables -A INPUT -p tcp -m state --state NEW -j DROP
```
