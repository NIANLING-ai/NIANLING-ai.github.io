---
title: mount镜像挂载
date: 2024-01-12 09:25:00
updated: 2024-01-12 12:00:00
tags: [挂载,mount]
excerpt: mount挂载本地镜像
categories: [Linux, mount]
---

# mount小知识：挂载镜像

## 简单挂载

```bash
#查看一下镜像有没有连接，这里是sr0
[root@server2 ~]# lsblk -l
NAME        MAJ:MIN RM  SIZE RO TYPE MOUNTPOINT
sda           8:0    0   20G  0 disk 
sda1          8:1    0    1G  0 part /boot
sda2          8:2    0   19G  0 part 
centos-root 253:0    0   17G  0 lvm  /
centos-swap 253:1    0    2G  0 lvm  [SWAP]
sr0          11:0    1  988M  0 rom  

#创建一个挂载目录
[root@server2 ~]# mkdir /mnt/centos7.9

#将镜像文件挂载到目录里，-t指定一下文件系统
[root@server2 ~]# mount -t iso9660 /dev/sr0 /mnt/centos7.9
mount: /dev/sr0 写保护，将以只读方式挂载

#可以将配置写进配置文件，开机自动挂载
echo "/dev/sr0  /mnt/centos7.9  iso9660 defaults 0 0" >> /etc/fstab

#如果开机有错误，将配置文件里自己添加的删除了就行
```
