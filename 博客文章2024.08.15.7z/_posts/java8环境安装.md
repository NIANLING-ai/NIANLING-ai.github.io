---
title: JDK8安装
date: 2024-01-05 09:25:00
updated: 2024-01-05 09:25:00
tags: [Linux, JDK8]
excerpt: Linux上jdk8的简单配置方法
categories: [Linux]
---
## JDK8安装
### rpm包下载
有Oracle jdk和openjdk两个版本，代码基本相同，但是推荐使用Oracle jdk
去官网下载：
https://www.oracle.com/java/technologies/downloads/#java8
或者其他正规渠道
### 安装
```bash
[root@localhost ~]# rpm -ivh jdk-8u202-linux-x64
警告：jdk-8u202-linux-x64.rpm: 头V3 RSA/SHA256 Signature, 密钥 ID ec551f03: NOKEY
准备中...                          ################################# [100%]
正在升级/安装...
   1:jdk1.8-2000:1.8.0_202-fcs        ################################# [100%]
Unpacking JAR files...
        tools.jar...
        plugin.jar...
        javaws.jar...
        deploy.jar...
        rt.jar...
        jsse.jar...
        charsets.jar...
        localedata.jar...

```
### 验证版本
```bash
[root@localhost ~]# java -version
java version "1.8.0_202"
Java(TM) SE Runtime Environment (build 1.8.0_202-b08)
Java HotSpot(TM) 64-Bit Server VM (build 25.202-b08, mixed mode)
```
### **修改profile文件**
```bash
[root@localhost ~]# vim /etc/profile
export JAVA_HOME=/usr/java/jdk1.8.0_202-amd64
export PATH=$PATH:$JAVA_HOME/bin:$JAVA_HOME/jre/bin
export CLASSPATH=$JAVA_HOME/lib:$JAVA_HOME/lib/tools.jar

[root@localhost ~]# source /etc/profile
```
### 没有特殊需求的时候
没有特殊需求也可以yum安装openjdk
#### 检查是否安装
```bash
[root@localhost ~]# rpm -qa|grep jdk 
或者 
[root@localhost ~]# yum list installed | grep jdk
```
#### 检测可用版本
```bash
[root@localhost ~]# yum search java | grep -i --color jdk
ldapjdk-javadoc.noarch : Javadoc for ldapjdk
openjdk-asmtools-javadoc.noarch : Javadoc for openjdk-asmtools
icedtea-web.x86_64 : Additional Java components for OpenJDK - Java browser
java-1.6.0-openjdk.x86_64 : OpenJDK Runtime Environment
java-1.6.0-openjdk-demo.x86_64 : OpenJDK Demos
java-1.6.0-openjdk-devel.x86_64 : OpenJDK Development Environment
java-1.6.0-openjdk-javadoc.x86_64 : OpenJDK API Documentation
java-1.6.0-openjdk-src.x86_64 : OpenJDK Source Bundle
java-1.7.0-openjdk.x86_64 : OpenJDK Runtime Environment
java-1.7.0-openjdk-accessibility.x86_64 : OpenJDK accessibility connector
java-1.7.0-openjdk-demo.x86_64 : OpenJDK Demos
java-1.7.0-openjdk-devel.x86_64 : OpenJDK Development Environment
java-1.7.0-openjdk-headless.x86_64 : The OpenJDK runtime environment without
java-1.7.0-openjdk-javadoc.noarch : OpenJDK API Documentation
java-1.7.0-openjdk-src.x86_64 : OpenJDK Source Bundle
java-1.8.0-openjdk.i686 : OpenJDK Runtime Environment 8
java-1.8.0-openjdk.x86_64 : OpenJDK 8 Runtime Environment
java-1.8.0-openjdk-accessibility.i686 : OpenJDK accessibility connector
java-1.8.0-openjdk-accessibility.x86_64 : OpenJDK accessibility connector
java-1.8.0-openjdk-demo.i686 : OpenJDK Demos 8
java-1.8.0-openjdk-demo.x86_64 : OpenJDK 8 Demos
java-1.8.0-openjdk-devel.i686 : OpenJDK Development Environment 8
java-1.8.0-openjdk-devel.x86_64 : OpenJDK 8 Development Environment
java-1.8.0-openjdk-headless.i686 : OpenJDK Headless Runtime Environment 8
java-1.8.0-openjdk-headless.x86_64 : OpenJDK 8 Headless Runtime Environment

```
#### **安装jdk1.8**
```bash
[root@localhost ~]# yum install -y java-1.8.0-openjdk.x86_64
[root@localhost ~]# java -version
openjdk version "1.8.0_392"
OpenJDK Runtime Environment (build 1.8.0_392-b08)
OpenJDK 64-Bit Server VM (build 25.392-b08, mixed mode)
```