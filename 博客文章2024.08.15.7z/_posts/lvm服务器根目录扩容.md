---
title: LVM服务器根目录扩容
date: 2024-01-18 09:25:00
updated: 2024-01-18 09:25:00
tags: [Linux, LVM]
excerpt: 服务器根目录扩容，两种情况
categories: [Linux, 运维]
---
# LVM服务器根目录扩容
## 新增加一块硬盘的情况
### 1.给根分区扩展容量

* 使用`fdisk-l` 查看磁盘分区路径  
  先在虚拟机里增加一块磁盘

```bash
[root@localhost ~]# fdisk -l

磁盘 /dev/sda：21.5 GB, 21474836480 字节，41943040 个扇区
Units = 扇区 of 1 * 512 = 512 bytes
扇区大小(逻辑/物理)：512 字节 / 512 字节
I/O 大小(最小/最佳)：512 字节 / 512 字节
磁盘标签类型：dos
磁盘标识符：0x000a0ffa

   设备 Boot      Start         End      Blocks   Id  System
/dev/sda1   *        2048     2099199     1048576   83  Linux
/dev/sda2         2099200    41943039    19921920   8e  Linux LVM

#这一个是新加的
磁盘 /dev/sdb：21.5 GB, 21474836480 字节，41943040 个扇区
Units = 扇区 of 1 * 512 = 512 bytes
扇区大小(逻辑/物理)：512 字节 / 512 字节
I/O 大小(最小/最佳)：512 字节 / 512 字节

#这个是原来的/目录
磁盘 /dev/mapper/centos-root：18.2 GB, 18249416704 字节，35643392 个扇区
Units = 扇区 of 1 * 512 = 512 bytes
扇区大小(逻辑/物理)：512 字节 / 512 字节
I/O 大小(最小/最佳)：512 字节 / 512 字节


磁盘 /dev/mapper/centos-swap：2147 MB, 2147483648 字节，4194304 个扇区
Units = 扇区 of 1 * 512 = 512 bytes
扇区大小(逻辑/物理)：512 字节 / 512 字节
I/O 大小(最小/最佳)：512 字节 / 512 字节
```

### 2.使用fdisk /dev/sdb 给新增硬盘进行分区

```bash
[root@localhost ~]# fdisk /dev/sdb
欢迎使用 fdisk (util-linux 2.23.2)。

更改将停留在内存中，直到您决定将更改写入磁盘。
使用写入命令前请三思。

Device does not contain a recognized partition table
使用磁盘标识符 0x5371ec78 创建新的 DOS 磁盘标签。

命令(输入 m 获取帮助)：n
Partition type:
   p   primary (0 primary, 0 extended, 4 free)
   e   extended
Select (default p): p
分区号 (1-4，默认 1)：
起始 扇区 (2048-41943039，默认为 2048)：
将使用默认值 2048
Last 扇区, +扇区 or +size{K,M,G} (2048-41943039，默认为 41943039)：
将使用默认值 41943039
分区 1 已设置为 Linux 类型，大小设为 20 GiB

命令(输入 m 获取帮助)：p

磁盘 /dev/sdb：21.5 GB, 21474836480 字节，41943040 个扇区
Units = 扇区 of 1 * 512 = 512 bytes
扇区大小(逻辑/物理)：512 字节 / 512 字节
I/O 大小(最小/最佳)：512 字节 / 512 字节
磁盘标签类型：dos
磁盘标识符：0x5371ec78

   设备 Boot      Start         End      Blocks   Id  System
/dev/sdb1            2048    41943039    20970496   83  Linux

命令(输入 m 获取帮助)：w
```

### 3.确定新增成功

`fdisk -l` 确定/dev/sdb/新增分区成功 新分区为/dev/sdb1

```bash
[root@localhost ~]# fdisk -l

磁盘 /dev/sda：21.5 GB, 21474836480 字节，41943040 个扇区
Units = 扇区 of 1 * 512 = 512 bytes
扇区大小(逻辑/物理)：512 字节 / 512 字节
I/O 大小(最小/最佳)：512 字节 / 512 字节
磁盘标签类型：dos
磁盘标识符：0x000a0ffa

   设备 Boot      Start         End      Blocks   Id  System
/dev/sda1   *        2048     2099199     1048576   83  Linux
/dev/sda2         2099200    41943039    19921920   8e  Linux LVM

磁盘 /dev/sdb：21.5 GB, 21474836480 字节，41943040 个扇区
Units = 扇区 of 1 * 512 = 512 bytes
扇区大小(逻辑/物理)：512 字节 / 512 字节
I/O 大小(最小/最佳)：512 字节 / 512 字节
磁盘标签类型：dos
磁盘标识符：0x5371ec78

   设备 Boot      Start         End      Blocks   Id  System
/dev/sdb1            2048    41943039    20970496   83  Linux

磁盘 /dev/mapper/centos-root：18.2 GB, 18249416704 字节，35643392 个扇区
Units = 扇区 of 1 * 512 = 512 bytes
扇区大小(逻辑/物理)：512 字节 / 512 字节
I/O 大小(最小/最佳)：512 字节 / 512 字节
```

### 4.使用LVM 给根分区扩展空间

* 使用vgdisplay 命令查看VG 组名

```bash
[root@localhost ~]# vgdisplay
  --- Volume group ---
  VG Name               centos
```

### 5.使用vgextend 命令把新增磁盘追加到centos VG组

```bash
[root@localhost ~]# vgextend centos /dev/sdb1
  Physical volume "/dev/sdb1" successfully created.
  Volume group "centos" successfully extended
```

### 6.添加完成之后使用vgdisplay 查看是否扩容成功

```bash
[root@localhost ~]# vgdisplay
  --- Volume group ---
  VG Name               centos
  System ID
  Format                lvm2
  Metadata Areas        2
  Metadata Sequence No  4
  VG Access             read/write
  VG Status             resizable
  MAX LV                0
  Cur LV                2
  Open LV               2
  Max PV                0
  Cur PV                2
  Act PV                2
  VG Size               38.99 GiB
  PE Size               4.00 MiB
  Total PE              9982
  Alloc PE / Size       4863 / <19.00 GiB
  Free  PE / Size       5119 / <20.00 GiB   #看这个
  VG UUID               uIB4kO-ywhz-ee5U-DzS7-Kja6-sPvZ-rbi3Bl
```

### 7.使用lvdisplay确定根分区路径

```bash
[root@localhost ~]# lvdisplay
  --- Logical volume ---
  LV Path                /dev/centos/root  #这里
  LV Name                root
  VG Name                centos
  LV UUID                VrUURF-GOCQ-TvkL-Yd4O-OYJk-ZMBo-gqMEaI
  LV Write Access        read/write
  LV Creation host, time localhost, 2023-09-14 13:18:10 +0800
  LV Status              available
  # open                 1
  LV Size                <17.00 GiB
  Current LE             4351
  Segments               1
  Allocation             inherit
  Read ahead sectors     auto
  - currently set to     8192
  Block device           253:0
```

### 8.使用lvresize 给根分区扩展空间

```bash
[root@localhost ~]# lvresize  -L +20G  /dev/centos/root
#分区增加必须得加-L +20G,如果不写+号会改变原磁盘空间
  Size of logical volume centos/root changed from <17.00 GiB (4351 extents) to <36.00 GiB (9215 extents).
  Logical volume centos/root successfully resized.
```

### 9.根分区磁盘增加成功之后使用xfs\_growfs /dev/centos/root 格式化磁盘空间

```bash
[root@localhost ~]# xfs_growfs /dev/centos/root
meta-data=/dev/mapper/centos-root isize=512    agcount=4, agsize=1113856 blks
         =                       sectsz=512   attr=2, projid32bit=1
         =                       crc=1        finobt=0 spinodes=0
data     =                       bsize=4096   blocks=4455424, imaxpct=25
         =                       sunit=0      swidth=0 blks
naming   =version 2              bsize=4096   ascii-ci=0 ftype=1
log      =internal               bsize=4096   blocks=2560, version=2
         =                       sectsz=512   sunit=0 blks, lazy-count=1
realtime =bash                   extsz=4096   blocks=0, rtextents=0
data blocks changed from 4455424 to 9436160
```

### 10.确认一下

```bash
[root@localhost ~]# df -h
文件系统                 容量  已用  可用 已用% 挂载点
devtmpfs                 898M     0  898M    0% /dev
tmpfs                    910M     0  910M    0% /dev/shm
tmpfs                    910M  9.6M  901M    2% /run
tmpfs                    910M     0  910M    0% /sys/fs/cgroup
/dev/mapper/centos-root   36G  1.3G   35G    4% /  #增加了
/dev/sda1               1014M  151M  864M   15% /boot
tmpfs                    182M     0  182M    0% /run/user/0
```
## 在原有空间上修改磁盘大小的情况

![](https://img-130165.oss-cn-shanghai.aliyuncs.com/img/xunihua.png)

- 比如从50G,直接修改成100G，新增加的磁盘是不识别的

### 1.新建分区

```bash
fdisk /dev/sda
n
p



w
#使用lvm方式的话，是下面的操作，上面是基于传统的分区
fdisk /dev/sda
n
p



t

L
8e
w
```

### 2.对新增的磁盘处理

```bash
partprobe #识别新增分区

pvcreate /dev/sda3  #使用 pvcreate 创建物理卷

pvdisplay #显示物理卷的属性 查看卷组信息

vgextend centos /dev/sda3  #使用vgextend命令动态扩展

lvresize -L +100%FREE /dev/mapper/centos-root  #扩招到/目录

xfs_growfs /dev/mapper/centos-root #重新识别/分区

df -h
```





